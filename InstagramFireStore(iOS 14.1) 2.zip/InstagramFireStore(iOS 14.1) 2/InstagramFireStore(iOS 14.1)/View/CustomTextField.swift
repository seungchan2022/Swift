//
//  CustomTextField.swift
//  InstagramFireStore(iOS 14.1)
//
//  Created by 승찬 on 2023/04/11.
//


import UIKit

class CustomTextField: UITextField {
    
    // MARK: - Properties
    
    // MARK: - Lifecycle
    
    init(placeholder: String) {
        super.init(frame: .zero)

        // placeholder 앞에 공백 넣는 법
        let spacer = UIView()
        spacer.setDimensions(height: 50, width: 12)
        leftView = spacer
        leftViewMode = .always
        
        borderStyle = .none
        textColor = .white      // 입력하는 텍스트
        keyboardAppearance = .dark
        backgroundColor = UIColor(white: 1, alpha: 0.1) // 텍스트 상자
        setHeight(50)
        attributedPlaceholder = NSAttributedString(string: placeholder,
                                                   attributes: [.foregroundColor: UIColor(white: 1, alpha: 0.7)])

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

