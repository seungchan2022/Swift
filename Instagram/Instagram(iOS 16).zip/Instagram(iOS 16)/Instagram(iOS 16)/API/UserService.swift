//
//  UserService.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/16.
//

// 데이터 베이스에서 사용자에 대한 정보를 가져오기 위해 사용자 개체를 만들어 사용
import Firebase

typealias FirestoreCompletion = (Error?) -> Void

struct UserService {
    
    // 현재 user의 정보를 얻어오는 함수 => 제대로된 프로필을 나타내기 위해
    // => input 파라미터를 넣어서 현재 유저에 대한 정보를 불러오는 것이 아니라 uid에 따른 유저의 정보를 불러오도록
    static func fetchUser(withUid uid: String, completion: @escaping(User) -> Void) {

        COLLECTION_USERS.document(uid).getDocument { snapshot, error in
//            print("DEBUG: Snapshot is \(snapshot?.data())")
            guard let dictionary = snapshot?.data() else { return }

            let user = User(dictionary: dictionary)
            completion(user)
        }
    }
    
    // 모든 사용자의 데이터를 얻는 함수 (DB에 있는 모든 유저들을 fetch하여 SearchController 리스트에 모두 나오도록)
    static func fetchUsers(completion: @escaping([User]) -> Void) {
        COLLECTION_USERS.getDocuments { (snapshot, error) in

            guard let snapshot = snapshot else { return }

//            var users = [User]()          // 빈 배열을 만들고
//            snapshot.documents.forEach { document in      // snapshot의 documents의 접근
//                let user = User(dictionary: document.data())  // 각 유저의 대한 데이터를 불러와서
//                users.append(user)        // 배열에 넣는다
//            }
//            completion(users)

            // 매핑으로 대체
            let users = snapshot.documents.map({ User(dictionary: $0.data()) })
            completion(users)
        }
    }
    
    // following -> currentUser uid -> user-following(collection) -> following uid(follow 당한 사람)    
    static func follow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).setData([:]) { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).setData([:], completion: completion)
        }
    }
    
    static func unfollow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).delete { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).delete(completion: completion)
        }
    }
    
    static func checkIfUserIsFollowed(uid: String, completion: @escaping(Bool) -> Void) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).getDocument { (snapshot, error) in
            
            // snashot.exists의 값은 Bool이다 => 존재하면: true, 존재하지 않으면: false
            guard let isFollowed = snapshot?.exists else { return }
            completion(isFollowed)
        }
    }
    
    static func fetchUserStats(uid: String, completion: @escaping(UserStats) -> Void) {
        
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { (snapshot, _) in
            
            let followers = snapshot?.documents.count ?? 0
            
            COLLECTION_FOLLOWING.document(uid).collection("user-following").getDocuments { (snapshot, _) in
                
                let following = snapshot?.documents.count ?? 0
                
                // post => postId (uid가 아니므로 유저에 맞는 포스트들을 찾아주어야 한다)
                COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid).getDocuments { (snapshot, _) in
                    
                    let posts = snapshot?.documents.count ?? 0
                    
                    completion(UserStats(followers: followers, following: following, posts: posts))
                }
            }
        }
    }
}
