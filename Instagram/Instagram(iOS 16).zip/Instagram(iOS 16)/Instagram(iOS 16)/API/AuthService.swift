//
//  AuthService.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/15.
//

import Firebase
import UIKit

typealias SendPasswordResetCallback = (Error?) -> Void

struct AuthCredentials {
    let email: String
    let password: String
    let fullname: String
    let username: String
    let profileImage: UIImage
}

struct AuthService {
    
    // 로그인 
    static func logUserIn(withEmail email: String, password: String, completion: @escaping(AuthDataResult?, Error?) -> Void) {
        
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
    }
    
    // 가입한 유저의 데이터를 DB에 넣는 로직
    // => 필요한 데이터: 이미지, 이메일, 패스워드, 풀네임, 유저네임 => credentials로 관리
    // 이미지 업로드 -> 업로드 후 다운로드 URL을 받고 -> 유저를 생성하고 -> 유저의 모든 정보를 업로드 한다.
    static func registerUser(withCredential credentials: AuthCredentials,
                             completion: @escaping(Error?) -> Void) {
        
        ImageUploader.uploadImage(image: credentials.profileImage) { imageUrl in
            
            Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) { (result, error) in
                if let error = error {
                    print("DEBUG: Failed to upload \(error.localizedDescription)")
                    return
                }
                
                // user의 id 생성
                guard let uid = result?.user.uid else { return }
                
                // 각 user에 넣을 데이터 설정
                let data: [String: Any] = ["email": credentials.email,
                                           "fullname": credentials.fullname,
                                           "username": credentials.username,
                                           "profileImageUrl": imageUrl,
                                           "uid": uid]
                
                // 경로에 맞게 데이터 설정
                COLLECTION_USERS.document(uid).setData(data, completion: completion)
            }
        }
    }
    
    // 비밀번호 재설정을 하기 위한 AuthServie 함수 구현
    // 비밀번호를 재설정하기 위해 이메일을 성공적으로 제출했음을 나타내야 합니다.
    static func resetPassword(withEmail email: String, completion: @escaping(SendPasswordResetCallback)) {
        
        Auth.auth().sendPasswordReset(withEmail: email, completion: completion)
    }
}
