//
//  ImageUploader.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/15.
//

import UIKit
import FirebaseStorage

// 이미지 데이터 => 파일 이름 설정 => 업로드할 경로 => 업로드할 경로를 만든곳에 데이터 넣기 => 로직을 다 수행 하고 나서 download (completion 수행)
struct ImageUploader {
    
    // 이미지 업로드 함수로 이미지를 업로드 할때마다 이코드를 액세스 하도록 한다.
    static func uploadImage(image: UIImage, completion: @escaping(String) -> Void) {
        
        // 이미지 데이터
        guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }
        
        // 파일 이름 설정
        let filename = NSUUID().uuidString
        
        // 업로드할 경로
        let ref = Storage.storage().reference(withPath: "/profile_images/\(filename)")
        
        // 업로드할 경로에 데이터 넣기
        ref.putData(imageData, metadata: nil) { metadata, error in
            if let error = error {
                print("DEBUG: Failed to upload imaeg \(error.localizedDescription)")
                return
            }
            
            // 위의 로직 다 수행한후 completion 수행
            ref.downloadURL { (url, error) in
                guard let imaegUrl = url?.absoluteString else { return }
                completion(imaegUrl)
            }
        }
    }
}
