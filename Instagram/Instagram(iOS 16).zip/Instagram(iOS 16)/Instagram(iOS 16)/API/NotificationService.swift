//
//  NotificationService.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/21.
//

import Firebase

struct NotificationService {
    
    // input parameter의 각각의 의미
    // => 게시물 올린 사람의 id, 누가 알림을 보냈는지(현재 로그인 된 사람이 알림을 보내는 사람이다), 알림 타입, 특정 게시물
    // => post가 nil인 이유: post에 대한 알림(like, post)이 아닌 다른 것에 대한 것(follow)일 수도 있다. => follow는 포스트와 상관 x
    // notifications -> user uid -> user-notifications(collection) -> id(notification id를 새로 생성해야 된다 : document id) -> data
    static func uploadNotification(toUid uid: String, fromUser: User, type: NotificationType, post: Post? = nil) {
        
        // 현재 로그인한 유저가 알림을 보내는 것이다
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        // 자기 자신에 대한 알림은 받지 않는다
        guard uid != currentUid else { return }
        
        // notifications -> user uid -> user-notifications -> notification id -> data 설정
        // => notification id를 document id로 새로 생성해야 한다
        // document id 추가 하는 법: document id를 넣을 문서를 따로 만들어서 -> setData
        // => 게시물을 올린 사람의 uid에 다가 추가하는 것이다
        // => docRef: notification id
        let docRef =    COLLECTION_NOTIFICATIONS.document(uid).collection("user-notifications").document()
        
        var data: [String: Any] = ["id": docRef.documentID,
                                   "timestamp": Timestamp(date: Date()),
                                   "type": type.rawValue,
                                   "uid": fromUser.uid,
                                   "userProfileImageUrl": fromUser.profileImageUrl,
                                   "username": fromUser.username]
        
        // post에 대한 것이면 추가하므로 위에 data를 var로 설정
        if let post = post {
            data["postId"] = post.postId
            data["postImageUrl"] = post.imageUrl
        }
        
        docRef.setData(data)
    }
    
    static func fetchNotifications(completion: @escaping([Notification]) -> Void) {
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let query = COLLECTION_NOTIFICATIONS.document(uid)
                        .collection("user-notifications").order(by: "timestamp", descending: true)
        
            query.getDocuments { snapshot, _ in
            
            guard let documents = snapshot?.documents else { return }
            
            let notifications = documents.map({ Notification(dictionary: $0.data() )})
            completion(notifications)
        }
    }
}
