//
//  CommentService.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/20.
//

import UIKit
import Firebase

struct CommentService {
    
    // DB에 comment 업로드
    static func uploadComment(comment: String, postID: String, user: User,
                              completion: @escaping(FirestoreCompletion)) {
        
        let data: [String: Any] = ["comment": comment,
                                   "profileImageUrl": user.profileImageUrl,
                                   "timestamp": Timestamp(date: Date()),
                                   "uid": user.uid,
                                   "username": user.username]
        
        // posts -> postID -> comments (collection) -> data
        COLLECTION_POSTS.document(postID).collection("comments")
                    .addDocument(data: data, completion: completion)
    }
    
    // post에 대해 comment를 다는것이므로 각 포스트에 대한 postID 필요
    static func fetchComments(forPost postID: String,
                              completion: @escaping([Comment]) -> Void) {
        
        var comments = [Comment]()
        let query = COLLECTION_POSTS.document(postID)
                        .collection("comments").order(by: "timestamp", descending: true)
        
        query.addSnapshotListener { (snapshot, error) in
            
            snapshot?.documentChanges.forEach({ change in
                if change.type == .added {
                    let data = change.document.data()
                    let comment = Comment(dictionaary: data)
                    comments.append(comment)
                }
            })
            completion(comments)
        }
    }
    
}
