//
//  PostService.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/17.
//

import UIKit
import Firebase

struct PostService {
    
    // DB에 포스트 업로드 하기
    static func uploadPost(caption: String, image: UIImage, user: User,
                           completion: @escaping(FirestoreCompletion)) {
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        ImageUploader.uploadImage(image: image) { imageUrl in
            
            let data: [String: Any] = ["caption": caption,
                                       "imageUrl": imageUrl,
                                       "likes": 0,
                                       "ownerImageUrl": user.profileImageUrl,
                                       "ownerUid": uid,
                                       "ownerUsername": user.username,
                                       "timestamp": Timestamp(date: Date())]
            
            let docRef = COLLECTION_POSTS.addDocument(data: data, completion: completion)
            
            self.updateUserFeedAfterPost(postId: docRef.documentID)
        }
    }
    
    // 모든 포스트 불러오기 (UserService의 fetchUsers와 유사)
    static func fetchPosts(completion: @escaping([Post]) -> Void) {
        COLLECTION_POSTS.order(by: "timestamp", descending: true)
            .getDocuments { (snapshot, error) in
                
                guard let documents = snapshot?.documents else { return }
                
                //            var posts = [Post]()
                //            documents.forEach { document in
                //                let post = Post(postId: document.documentID, dictionary: document.data())
                //                posts.append(post)
                //            }
                //            completion(posts)
                let posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data())})
                completion(posts)
            }
    }
    
    // 각 유저에 맞는 포스트 불러오기
    static func fetchPosts(forUser uid: String, completion: @escaping([Post]) -> Void) {
        
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid) // 각 유저에 맞게
        
        query.getDocuments { (snapshot, error) in
            
            guard let documents = snapshot?.documents else { return }
            
            //            var posts = [Post]()
            //            documents.forEach { document in
            //                let post = Post(postId: document.documentID, dictionary: document.data())
            //                posts.append(post)
            //            }
            //            posts.sort { post1, post2 in
            //                post1.timestamp.seconds > post2.timestamp.seconds
            //            }
            //            completion(posts)
            
            var posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data())})
            
            // 최신것이 앞으로 오도록
            posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds})
            completion(posts)
        }
    }
    
    // postId를 통해 post에 대한 Feed가 나오도록
    static func fetchPost(withPostId postId: String, completion: @escaping(Post) -> Void) {
        
        COLLECTION_POSTS.document(postId).getDocument { snapshot, _ in
            
            guard let snapshot = snapshot else { return }
            guard let data = snapshot.data() else { return }
            
            let post = Post(postId: snapshot.documentID, dictionary: data)
            completion(post)
        }
    }
    
    // => like를 누르면 post-likes와 user-likes 둘다 데이터가 변함
    // posts -> postID -> post-likes(collection) -> 좋아요를 누른 uid (현재 유저)
    static func likePost(post: Post, completion: @escaping(FirestoreCompletion)) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes + 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).setData([:]) { _ in
            // users -> uid -> user-likes -> postId
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).setData([:], completion: completion)
        }
    }
    
    static func unLikePost(post: Post, completion: @escaping(FirestoreCompletion)) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard post.likes > 0 else { return }    // 좋아요는 0보다 작을수 x
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes - 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).delete { _ in
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).delete(completion: completion)
        }
    }
    
    // 좋아요가 제대로 되었는지 => user-likes의 postId가 존재하면 좋아요인 상태
    // => checkIfUserFollowed 와 유사
    static func checkIfUserLikedPost(post: Post, completion: @escaping(Bool) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).getDocument { (snapshot, _) in
            
            guard let didLike = snapshot?.exists else { return }
            completion(didLike)
        }
    }
    
    // (user-feed에 있는 posts를 fetch ⇒ follow되어있는 유저의 postId만 불러오는것)
    static func fetchFeedPosts(completion: @escaping([Post]) -> Void) {//
        guard let uid = Auth.auth().currentUser?.uid else { return }
        var posts = [Post]()
        
        // user-feed에 있는 document의 Id를 통해 (postId) 그거에 해당 하는 post를 fetch한다.
        COLLECTION_USERS.document(uid).collection("user-feed").getDocuments { snapshot, error in
            snapshot?.documents.forEach({ document in
                // user-feed에있는 documentID가 postId이다.
                fetchPost(withPostId: document.documentID) { post in
                    posts.append(post)
                    
                    // 최신것이 제일 위로 오도록
                    posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds })
                    completion(posts)
                }
            })
        }
    }
    
    // 누군가를 팔로우할 때 사용자 피드를 업데이트 하는 함수 (follow한 유저들의 포스트만 보이도록)
    // => 모든 포스트를 찾고 특정 유저에 속한 포스트들을 유저 피드에 추가한다.
    // => following한 user의 feed에 대한 정보
    // => 포스트의 ownerUid를 보고 팔로우한 유저면 user-feed에 세팅하기 위해
    // => unfollow 이면 delete하기 위해 input 파라미터로 didFollow 추가
    static func updateUserFeedAterFollowing(user: User, didFollow: Bool) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: user.uid) // 특정 유저
        
        query.getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else { return }
            
            let docIDs = documents.map({ $0.documentID })   // => 포스트에 대한 정보(docIDs)
            
            // docIDs의 id를 한개씩 돌면서 데이터 세팅
            // users -> user id -> user-feed(collection) -> post에 대한 정보(docIDs)
            docIDs.forEach { id in
                if didFollow {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).setData([:])
                } else {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).delete()
                }
            }
        }
    }
    
    // 새로운 이미지 업로드 후 팔로우 하는 사람들이 보이도록 세팅 => DB에 업로드 하는 과정!!!!!
    private static func updateUserFeedAfterPost(postId: String) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        // 현재 로그인된 유저를 팔로우 하는 사람들의 데이터를 얻기 위해
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { snapshot, _ in
            
            guard let documents = snapshot?.documents else { return } // 현재 로그인된 유저를 팔로우 하는 사람들
            
            documents.forEach { document in
                // 팔로우 하는 사람들에게 포스트를 세팅하고
                COLLECTION_USERS.document(document.documentID).collection("user-feed").document(postId).setData([:])
            }
            
//            // 나의 user-feed또한 업데이트 한다. => ??? 어쩌피 본인 포스트는 피드에 안나오는데 왜?
//            COLLECTION_USERS.document(uid).collection("user-feed").document(postId).setData([:])
        }
    }
}
