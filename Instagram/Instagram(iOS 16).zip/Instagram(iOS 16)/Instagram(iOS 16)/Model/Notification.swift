//
//  Notification.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/20.
//

import UIKit
import Firebase

// 알림의 종류가 여러개 이므로 enum으로 case를 나누어서 각 case마다 나오는 메세지가 다르게 표현
// type을 String보다 Int로 표현 하는게 더 효율적 (스펠링 실수, 코드 길이 등등..)
enum NotificationType: Int {    // 각 case를 Int로 나타내어 rawValue로 사용
    case like
    case follow
    case comment
    
    // case에 따라 나오는 메시지를 다르게 하기 위해
    var notificationMeessage: String {
        switch self {
        case .like:
            return "  liked your post.."
        case .follow:
            return "  started following you."
        case .comment:
            return "  commented your post.."
        }
    }
}

struct Notification {
    let id: String  // notification id (postId 같은 개념)
    // notification에서 follow는 post의 데이터가 필요하지 않으므로 옵셔널로 표현
    var postId: String?
    var postImageUrl: String?
    let timestamp: Timestamp
    let type: NotificationType
    let uid: String
    let userProfileImageUrl: String
    let username: String
    
    // isFollowed와 유사 (follow 했는지 알려줄 변수)
    var userFollow = false
    
    init(dictionary: [String: Any]) {
        self.id = dictionary["id"] as? String ?? ""
        self.postId = dictionary["postId"] as? String ?? ""
        self.postImageUrl = dictionary["postImageUrl"] as? String ?? ""
        self.type = NotificationType(rawValue: dictionary["type"] as? Int ?? 0) ?? .like
        self.timestamp = dictionary["timestamp"] as? Timestamp ?? Timestamp(date: Date())
        self.uid = dictionary["uid"] as? String ?? ""
        self.userProfileImageUrl = dictionary["userProfileImageUrl"] as? String ?? ""
        self.username = dictionary["username"] as? String ?? ""
    }
}
