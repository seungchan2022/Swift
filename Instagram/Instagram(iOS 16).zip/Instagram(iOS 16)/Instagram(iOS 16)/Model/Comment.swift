//
//  Comment.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/19.
//

import Foundation
import Firebase

struct Comment {
    let commentText: String
    let profileImageUrl: String
    let timestamp: Timestamp
    let uid: String
    let username: String
    
    init(dictionaary: [String: Any]) {
        self.commentText = dictionaary["comment"] as? String ?? ""
        self.profileImageUrl = dictionaary["profileImageUrl"] as? String ?? ""
        self.timestamp = dictionaary["timestamp"] as? Timestamp ?? Timestamp(date: Date())
        self.uid = dictionaary["uid"] as? String ?? ""
        self.username = dictionaary["username"] as? String ?? ""
    }
}
