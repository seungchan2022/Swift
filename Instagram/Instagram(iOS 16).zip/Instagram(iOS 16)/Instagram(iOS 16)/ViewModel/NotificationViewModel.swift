//
//  NotificationViewModel.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/21.
//

import UIKit
import Firebase

struct NotificationViewModel {
    var notification: Notification
    
    init(notification: Notification) {
        self.notification = notification
    }

    var profileImageUrl: URL? { return URL(string: notification.userProfileImageUrl) }
    
    var postImageUrl: URL? { return URL(string: notification.postImageUrl ?? "")}
 
    var username: String { return notification.username }
    
    var message: String { return notification.type.notificationMeessage }
    
    var timestampString: String? {
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.second, .minute, .hour, .day, .weekOfMonth]
        formatter.maximumUnitCount = 1
        formatter.unitsStyle = .abbreviated
        formatter.calendar!.locale = Locale(identifier: "en_AU")
        return formatter.string(from: notification.timestamp.dateValue(), to: Date())
    }
    
    var notificationMessage: NSAttributedString {
        
        let attributedText = NSMutableAttributedString(string: username, attributes: [.font: UIFont.boldSystemFont(ofSize: 14)])
        attributedText.append(NSAttributedString(string: message, attributes: [.font: UIFont.systemFont(ofSize: 14)]))
        attributedText.append(NSAttributedString(string: "  \(timestampString ?? "")", attributes: [.font: UIFont.systemFont(ofSize: 13), .foregroundColor: UIColor.lightGray]))
        
        return attributedText
    }
    
    // 타입이 follow이면 포스트이미지가 안보이도록
    var shouldHidePostImage: Bool { return notification.type == .follow }
    
    var followButtonText: String {
        return notification.userFollow ? "Following" : "Follow"
    }
    
    var followButtonBackgroundColor: UIColor {
        return notification.userFollow ? .white : .systemBlue
    }
    
    var followButtonTextColor: UIColor {
        return notification.userFollow ? .black : .white
    }
}
