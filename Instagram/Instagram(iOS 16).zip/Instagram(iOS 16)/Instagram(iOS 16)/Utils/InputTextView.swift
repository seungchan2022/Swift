//
//  InputTextView.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/17.
//

// TextView를 custom TextView를 만들어서 사용
// Enter caption에 입력하면 placeholder가 사라졌다가 다시 다 지우면 다시 나타남
// customInputView를 클래스 또는 서브 클래스로 할때 재사용 가능

import UIKit

class InputTextView: UITextView {
    
    // MARK: - Properties
    
    var placeholerText: String? {
        didSet { placeholderLabel.text = placeholerText }
    }
    
    let placeholderLabel: UILabel = {
        let label = UILabel()
        label.textColor = .lightGray
        return label
    }()
    
    // => ???
    var placeholderShouldCenter = true {
        didSet {
            if placeholderShouldCenter {
                placeholderLabel.anchor(left: leftAnchor, right: rightAnchor,
                                        paddingLeft: 8, paddingRight: 8)
                placeholderLabel.centerY(inView: self)
            } else {
                placeholderLabel.anchor(top: safeAreaLayoutGuide.topAnchor,
                                        left: leftAnchor, paddingTop: 6, paddingLeft: 7)
            }
        }
    }
    
    // MARK: - Lifecycle
    
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        
        addSubview(placeholderLabel)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleTextDidChange),
                                               name: UITextView.textDidChangeNotification,
                                               object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Actions
    
    @objc func handleTextDidChange() {
        placeholderLabel.isHidden = !text.isEmpty
    }
}
