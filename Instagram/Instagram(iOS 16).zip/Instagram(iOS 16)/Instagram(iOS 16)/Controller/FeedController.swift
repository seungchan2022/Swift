//
//  FeedController.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/15.
//

import UIKit
import Firebase

private let reuseIdentifier = "FeedCell"

class FeedController: UICollectionViewController {
    
    // MARK: - Properties
    
    // => posts가 세팅될때 마다 didSet이 수행되므로 포스트의 like가 바뀔때마다 데이터를 다시 reload해야 되기 때문에 여기다 작성 ??
    private var posts = [Post]() {
        didSet { collectionView.reloadData() }
    }
    
    // post가 nil이면 모든 포스트를 불러오고 아니면 하나의 포스트만 불러오기 위해 프로퍼티 생성
    // 즉, 기본적으로 우리가하고 싶은 것은이 게시자에게 가치가있는 경우에만,
    //  피드에 게시물 1개를 표시합니다.
    //    그렇지 않은 경우 이 모든 소식을 봅니다.
    //  Profile에서 게시물을 눌렀을때 Feed에 모든 게시물이 아닌 누른 게시물만 나오게 하기 위해
    var post: Post? {
        didSet { collectionView.reloadData() }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        fetchPosts()
        
        // single post일때 좋아요 카운트가 제대로 안되므로 ?? => 이해 X
        if post != nil {
            checkIfUserLikedPosts()
        }
    }
    
    // MARK: - Actions
    
    @objc func handleLogOut() {
        do {    // 로그아웃을 하면 로그인 페이지가 나와야 된다.
            try Auth.auth().signOut()   // 로그아웃 하는 로직
            let controller = LoginController()
            
            // => ????
            controller.delegate = self.tabBarController as? MainTabController
            let nav = UINavigationController(rootViewController: controller)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav, animated: true, completion: nil)
        } catch {
            print("DEBUG: Failed to log out..")
        }
    }
    
    // 새로고침
    @objc func handleRefresh() {
        posts.removeAll()
        fetchPosts()
    }
    
    // MARK: - API
    
    func fetchPosts() {
        // post가 nil이 아닌 경우에만 모든 포스트를 불러옴
        guard post == nil else { return }
                
        PostService.fetchFeedPosts { posts in
            self.posts = posts
            // fetch할때 마다 좋아요 상태인지 확인하지 말고 => 먼저 모든 포스트 fetch => 그 이후 index를 활용하여 posts를 확인하면서 좋아요 상태인지 확인
            self.checkIfUserLikedPosts()
            self.collectionView.refreshControl?.endRefreshing()
        }
    }
    
    // fetch할때 마다 좋아요 상태인지 확인하지 말고 => 먼저 모든 포스트 fetch => 그 이후 index를 활용하여 posts를 확인하면서 좋아요 상태인지 확인
    // 모든 posts를 fetch 하고 모든 posts가 세팅된 후에 실행
    func checkIfUserLikedPosts() {
        if let post = post {        // single post인 경우
            PostService.checkIfUserLikedPost(post: post) { didLike in
                self.post?.didLike = didLike
            }
        } else {
            posts.forEach { post in
                PostService.checkIfUserLikedPost(post: post) { didLike in
    //                print("DEBUG: Caption is \(post.caption) did like is \(didLike)")
                    if let index = self.posts.firstIndex(where: { $0.postId == post.postId }) {
                        self.posts[index].didLike = didLike
                    }
                }
            }
        }
    }
    
    
    // MARK: - Helpers
    
    func configureView() {
        collectionView.backgroundColor = .white
        navigationItem.title = "Feed"
        
        collectionView.register(FeedCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        if post == nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Log Out",
                                                               style: .plain,
                                                               target: self,
                                                               action: #selector(handleLogOut))
        }
        
        // 새로고침 UI
        let refresher = UIRefreshControl()
        refresher.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        collectionView.refreshControl = refresher
    }
}

// MARK: - UICollectionViewDataSource

extension FeedController {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return post == nil ? posts.count : 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! FeedCell
        
        if let post = post {    // 포스트가 값이 있으면 그 포스트에 정보만 불러온다
            cell.viewModel = PostViewModel(post: post)
        } else {
            cell.viewModel = PostViewModel(post: posts[indexPath.row])
        }
        
        cell.delegate = self
        return cell
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension FeedController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = view.frame.width
        var height = width + 8 + 40 + 8
        height += 60
        height += 50
        
        return CGSize(width: width, height: height)
    }
}

// MARK: - FeedCelleDelegate

extension FeedController: FeedCelleDelegate {
    func cell(_ cell: FeedCell, wantsToShowProfileFor uid: String) {
        UserService.fetchUser(withUid: uid) { user in
            let controller = ProfileController(user: user)
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
   
    func cell(_ cell: FeedCell, wantsToShowCommentFor post: Post) {
        let controller = CommentController(post: post)
        navigationController?.pushViewController(controller, animated: true)
    }
    
    func cell(_ cell: FeedCell, didLikeFor post: Post) {
        
        // 현재 유저에 대한 데이터가 필요하므로 MainTab에서 가져온다
        guard let tab = tabBarController as? MainTabController else { return }
        guard let user = tab.user else { return }
        
        // 우리가 원하는 것: didLike가 toggle되면서 좋아요가 되었다가 안되었다가 하는것
        //  => post에 데이터는 viewModel에 있고 우리가 불러오는 데이터는 viewModel에서 불러오는 것이므로 post.didLike.toggle() 이렇게 적으면 x
        //  => MVVM 형식이기 때문 (view가 model을 가지고있지 않고 model은 vieModel이 가지고 있는 패턴)
        cell.viewModel?.post.didLike.toggle()
        if post.didLike {
            PostService.unLikePost(post: post) { _ in
                cell.viewModel?.post.likes = post.likes - 1
            }
        } else {
            PostService.likePost(post: post) { _ in
                cell.viewModel?.post.likes = post.likes + 1
                
                // input parameter의 각각의 의미
                // => 게시물 올린 사람의 id, 누가 알림을 보냈는지, 알림 타입, 특정 게시물
                // => 현재 게시물에 좋아요를 눌렀으므로 post.ownerUid에 알림이 가야된다.
                NotificationService.uploadNotification(toUid: post.ownerUid, fromUser: user,
                                                       type: .like, post: post)
            }
        }
    }
}
