//
//  MainTabController.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/15.
//

import UIKit
import Firebase
import YPImagePicker

class MainTabController: UITabBarController {
    
    // MARK: - Properties
    
    // 다른 곳에서 현재 유저에 대한 정보를 받기 위해 private 제거
    // => 현재 로그인된 유저
    var user: User? {
        didSet {
            guard let user = user else { return }
            configureViewControllers(withUser: user)
        }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkIfUserLoggedIn()
        fetchUser()
    }
    
    // MARK: - API
    
    // 로그인이 되었으면 바로 메인뷰를 보여주고 로그인이 안된 상태라면 로그인 화면을 보여주기 위해
    func checkIfUserLoggedIn() {
        if Auth.auth().currentUser == nil { // 로그인이 안된 상태면 로그인 화면을 띄움 => 현재 유저가 없으면
            DispatchQueue.main.async {
                let controller = LoginController()
                controller.delegate = self
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: true, completion: nil)
            }
        }
    }
    
    // MainTab에서 user를 fetch하고 각 viewController에서는 init을 통해서 => ?
    // Tabbaa 컨트롤러에서 사용자를 검색한 다음 View Controller를 초기화합니다.
    // => 여기서는 현재 유저에 대한 정보를 불러온다
    func fetchUser() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        UserService.fetchUser(withUid: uid) { user in
            self.user = user
        }
    }
    
    // MARK: - Helpers
    
    // input 파라미터를 넣는 이유: ProfileController의 user는 옵셔널이 아니지만 MainTab의 user 옵셔널이므로
    func configureViewControllers(withUser user: User) {
        view.backgroundColor = .white
        self.delegate = self
        
        // navigation background 설정
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.9)
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
        
        let layout = UICollectionViewFlowLayout()
        let feed = configureTabBarImage(unselected: UIImage(named: "home_unselected")!, selected: UIImage(named: "home_selected")!, rootViewController: FeedController(collectionViewLayout: layout))
        
        let search = configureTabBarImage(unselected: UIImage(named: "search_unselected")!, selected: UIImage(named: "search_selected")!, rootViewController: SearchController())
        
        let imageSelector = configureTabBarImage(unselected: UIImage(named: "plus_unselected")!, selected: UIImage(named: "plus_unselected")!, rootViewController: ImageSelectorController())
        
        let notification = configureTabBarImage(unselected: UIImage(named: "like_unselected")!, selected: UIImage(named: "like_selected")!, rootViewController: NotificationController())
    
        let profileController = ProfileController(user: user)
        let profile = configureTabBarImage(unselected: UIImage(named: "profile_unselected")!, selected: UIImage(named: "profile_selected")!, rootViewController: profileController)
        
        viewControllers = [feed, search, imageSelector, notification, profile]
        
        tabBar.tintColor = .black
        
    }
    
    // 일반 이미지와 선택했을때 이미지가 다름
    func configureTabBarImage(unselected: UIImage, selected: UIImage, rootViewController: UIViewController) -> UINavigationController {
        
        let nav = UINavigationController(rootViewController: rootViewController)
        nav.tabBarItem.image = unselected
        nav.tabBarItem.selectedImage = selected
        nav.navigationBar.tintColor = .black
        return nav
    }

    func didFinishPickMedia(_ picker: YPImagePicker) {
        picker.didFinishPicking { items, _ in
            picker.dismiss(animated: false) {
                
                guard let selectedImage = items.singlePhoto?.image else { return }
                
                let controller = UploadPostController()
                // 여기서 선택한 이미지와 UplodPost에서 나와야 될 이미지가 같아야 된다.
                controller.selectedImage = selectedImage
                controller.delegate = self  // UploadPostControllerDelegate
                
                // 현재 로그인한 유저가 게시물을 업로드 => 설정 안해주면 업로드 안됌
                // => 이미지 선택후 UploadController의 게시물을 업데이트 하는 현재 유저와 메인 탭의 유저가 같아야 된다?
                controller.currentUser = self.user // => ???
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: false, completion: nil)
            }
        }
    }
}

// MARK: - AuthenticationDelegate

extension MainTabController: AuthenticationDelegate {
    func authenticationDidComplete() {
        fetchUser()
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITabBarControllerDelegate

// shouldSelect 대신 didSelect로 구현해보기 => shouldSelect로 표현하면 return 값이 Bool 값이므로 마지막에 bool값을 return 해주어야 한다.
extension MainTabController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        
        // index가 필요한 이유: MainTab에서 어떤 v.c를 선택했을때 이미지를 선택하는 메서드를 실행해야 되는지 알기 위해
        let index = viewControllers?.firstIndex(of: viewController)
        
        if index == 2 {
            var config = YPImagePickerConfiguration()
            config.library.mediaType = .photo
            config.shouldSaveNewPicturesToAlbum = false
            config.startOnScreen = .library
            config.screens = [.library]
            config.hidesBottomBar = false
            config.hidesStatusBar = false
            config.library.maxNumberOfItems = 1

            let picker = YPImagePicker(configuration: config)
            picker.modalPresentationStyle = .fullScreen
            present(picker, animated: true, completion: nil)
            
            didFinishPickMedia(picker)
        }
    }
}

// MARK: - UploadPostControllerDelegate

extension MainTabController: UploadPostControllerDelegate {
    func controllerDidFinishUploader(_ controller: UploadPostController) {
        selectedIndex = 0
        controller.dismiss(animated: true, completion: nil)
        
        // 이미지 업로드후 업로드한 데이터가 바로 FeedController에 업로드된 상태로 나타나야 한다.
        // => viewControllers를 사용하여 Tabbar의 각 viewController에 접근할 수 있다.
        // => MainTab에 있는 viewController들은 UINavigationController이므로 주의 필요
        // => UINavigationController를 찾고 FeedController를 찾고 FeedController에서 작성했던 handleRefresh 사용 (업데이트를 하여 화면에 게시물이 나오도록)
        // => ??
        guard let feedNav = viewControllers?.first as? UINavigationController else { return }
        guard let feed = feedNav.viewControllers.first as? FeedController else { return }
        feed.handleRefresh()
    }
}
