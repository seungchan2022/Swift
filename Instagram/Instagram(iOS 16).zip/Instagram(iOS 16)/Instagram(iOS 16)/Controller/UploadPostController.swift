//
//  UploadPostController.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/17.
//

import UIKit


// Upload post 이후 메인 페이지가 나오게 하기 위해 프로토콜을 사용하여 delegate 수행
protocol UploadPostControllerDelegate: class {
    func controllerDidFinishUploader(_ controller: UploadPostController)
}

class UploadPostController: UIViewController  {
    
    // MARK: - Properties
    
    // 현재 로그인한 유저가 게시물을 업로드 하므로 currentUser가 필요
    var currentUser: User?
    
    var selectedImage: UIImage? {
        didSet { postImageView.image = selectedImage }
    }
    
    weak var delegate: UploadPostControllerDelegate?
    
    private let postImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()
    
    private lazy var captionTextView: InputTextView = {
        let tv = InputTextView()
        tv.placeholerText = "Enter caption.."
        tv.font = UIFont.systemFont(ofSize: 16)
        tv.delegate = self
        tv.placeholderShouldCenter = false
        return tv
    }()
    
    private let countLabel: UILabel = {
        let label = UILabel()
        label.text = "0/100"
        label.textColor = .lightGray
        label.font = UIFont.systemFont(ofSize: 15)
        return label
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    // MARK: - Actions
    
    @objc func didTapCancel() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func didTapDone() {
        guard let caption = captionTextView.text else { return }
        guard let image = selectedImage else { return }
        guard let user = currentUser else { return }
        
        showLoading()
        
        PostService.uploadPost(caption: caption, image: image, user: user) { error in
            
            self.hideLoading()
            if let error = error {
                print("DEBUG: Failed to upload post \(error.localizedDescription)")
                return
            }
            
            self.delegate?.controllerDidFinishUploader(self)
//            self.dismiss(animated: true, completion: nil)
            print("DEBUG: Successfully upload")
        }
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        view.backgroundColor = .white

        navigationItem.title = "Upload Post"
        navigationController?.navigationBar.tintColor = .black
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel,
                                                           target: self,
                                                           action: #selector(didTapCancel))
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Share",
                                                            style: .done,
                                                            target: self,
                                                            action: #selector(didTapDone))
        
        view.addSubview(postImageView)
        postImageView.centerX(inView: view,
                              topAnchor: view.safeAreaLayoutGuide.topAnchor, paddingTop: 8)
        postImageView.setDimensions(height: 180, width: 180)
        postImageView.layer.cornerRadius = 10
        
        view.addSubview(captionTextView)
        captionTextView.anchor(top: postImageView.bottomAnchor, left: view.leftAnchor,
                               right: view.rightAnchor, paddingTop: 16,
                               paddingLeft: 12, paddingRight: 12, height: 80)
        
        let divider = UIView()
        divider.backgroundColor = .lightGray
        view.addSubview(divider)
        divider.anchor(top: captionTextView.topAnchor, left: view.leftAnchor,
                       right: view.rightAnchor, height: 1)
        
        view.addSubview(countLabel)
        countLabel.anchor(top: captionTextView.bottomAnchor, right: view.rightAnchor,
                          paddingTop: 16, paddingRight: 12)
        
    }
    
    // 글자수 제한 함수
    func checkMaxLength(_ textView: UITextView) {
        if textView.text.count > 100 {
            textView.deleteBackward()
        }
    }
}

// MARK: - UITextViewDelegate

extension UploadPostController: UITextViewDelegate {
    // 해야 할일: 1. count label, 2. 100글자 이상 x
    func textViewDidChange(_ textView: UITextView) {
        checkMaxLength(textView)
        let count = textView.text.count
        countLabel.text = "\(count)/100"
    }
}


