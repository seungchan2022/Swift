//
//  NotificationController.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/15.
//

import UIKit

private let reuseIdentifier = "NotificationCell"

class NotificationController: UITableViewController {
    
    // MARK: - Properties
    
    private var notifications = [Notification]() {
        didSet { tableView.reloadData() }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        fetchNotifications()
    }
    
    // MARK: - Actions
    
    @objc func handleRefresh() {
        notifications.removeAll()
        fetchNotifications()
//        tableView.refreshControl?.endRefreshing()
    }
    
    // MARK: - API
    
    func fetchNotifications() {
        NotificationService.fetchNotifications { notifications in
            self.notifications = notifications
            self.checkIfUserIsFollowed()
            self.tableView.refreshControl?.endRefreshing()
        }
    }
    
    // checkIfUserLikedPosts와 유사
    func checkIfUserIsFollowed() {
        notifications.forEach { notification in
            guard notification.type == .follow else { return }
            
            UserService.checkIfUserIsFollowed(uid: notification.uid) { isFollowed in
//                여기서 notification id를 통해 notifiction중에서 팔로우인것을 찾는것?
                if let index = self.notifications.firstIndex(where: { $0.id == notification.id }) {
                    self.notifications[index].userFollow = isFollowed
                }
            }
        }
    }
    
    
    // MARK: - Helpers
    
    func configureTableView() {
        view.backgroundColor = .white
        navigationItem.title = "Notifications"
        
        tableView.rowHeight = 64
        tableView.register(NotificationCell.self, forCellReuseIdentifier: reuseIdentifier)
        
        // 새로고침 UI
        let refresher = UIRefreshControl()
        refresher.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        tableView.refreshControl = refresher
    }
}

// MARK: - UITableViewDataSource

extension NotificationController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notifications.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! NotificationCell
        cell.viewModel = NotificationViewModel(notification: notifications[indexPath.row])
        cell.delegate = self
        return cell
    }
}

// MARK: - UITableViewDelegate

extension NotificationController {
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        UserService.fetchUser(withUid: notifications[indexPath.row].uid) { user in
            let controller = ProfileController(user: user)
            self.navigationController?.pushViewController(controller, animated: true)
            print("DEBUG: Show \(self.notifications[indexPath.row].username)  profile" )
        }
    }
}

// MARK: - NotificationCellDelegate

extension NotificationController: NotificationCellDelegate {
    func cell(_ cell: NotificationCell, wantsToFollow uid: String) {
        
        showLoading()
        
        UserService.follow(uid: uid) { _ in

            self.hideLoading()

            cell.viewModel?.notification.userFollow.toggle()
        }
    }
    
    func cell(_ cell: NotificationCell, wantsToUnfollow uid: String) {
        
        showLoading()
        
        UserService.unfollow(uid: uid) { _ in
            
            self.hideLoading()
            
            cell.viewModel?.notification.userFollow.toggle()
        }
    }
    
    func cell(_ cell: NotificationCell, wantsToViewPost postId: String) {
        
        showLoading()
        
        PostService.fetchPost(withPostId: postId) { post in
            
            self.hideLoading()
            
            let controller = FeedController(collectionViewLayout: UICollectionViewFlowLayout())
            controller.post = post  // 하나의 Feed만 나오도록
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
}

