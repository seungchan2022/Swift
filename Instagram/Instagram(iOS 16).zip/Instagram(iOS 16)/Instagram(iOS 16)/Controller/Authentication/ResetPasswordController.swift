//
//  ResetPasswordController.swift
//  Instagram(iOS 16)
//
//  Created by 승찬 on 2023/05/22.
//

import UIKit

protocol ResetPasswordControllerDelegate: class {
    func controllerDidSendResetPasswordLink(_ cell: ResetPasswordController)
}

class ResetPasswordController: UIViewController {
    
    // MARK: - Properties
    
    var viewModel = ResetViewModel()
    
    weak var delegate: ResetPasswordControllerDelegate?
    
    private let iconImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.image = UIImage(named: "Instagram_logo_white")
        return iv
    }()
    
    private let emailTextField: CustomTextField = {
        let tf = CustomTextField(placeholder: "Email")
        return tf
    }()

    private let resetButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = UIColor.systemPurple.withAlphaComponent(0.5)
        button.setTitle("Reset Password", for: .normal)
        button.setTitleColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.setHeight(50)
        button.isEnabled = false
        button.addTarget(self, action: #selector(handleReset), for: .touchUpInside)
        return button
    }()

    private let backButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: #selector(handleShowLogIn), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureViewController()
    }
    
    // MARK: - Actions
    
    @objc func handleReset() {
        guard let email = emailTextField.text else { return }
        
        showLoading()
        
        AuthService.resetPassword(withEmail: email) { error in
            
            self.hideLoading()
            
            if let error = error {
                self.showMessage(withTitle: "Erorr", message: error.localizedDescription)
                return
            }
            self.delegate?.controllerDidSendResetPasswordLink(self)
        }
    }
    
    @objc func handleShowLogIn() {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func textDidChange(sender: UITextField) {
        if sender == emailTextField {
            viewModel.email = sender.text
        }
        updateForm()
    }
    
    // MARK: - Helpers
    
    func configureViewController() {
        
        configureGradient()
        
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        
        view.addSubview(iconImageView)
        iconImageView.setDimensions(height: 80, width: 120)
        iconImageView.centerX(inView: view,
                              topAnchor: view.safeAreaLayoutGuide.topAnchor,
                              paddingTop: 32)
        
        configureStackView()
        
        view.addSubview(backButton)
        backButton.anchor(top: view.safeAreaLayoutGuide.topAnchor,
                          left: view.leftAnchor,
                          paddingTop: 20,
                          paddingLeft: 20)
    }
    
    func configureStackView() {
        let stack = UIStackView(arrangedSubviews: [emailTextField, resetButton])
        stack.axis = .vertical
        stack.spacing = 20
        
        view.addSubview(stack)
        stack.anchor(top: iconImageView.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 16, paddingLeft: 32, paddingRight: 32)
    }
}

// MARK: - FormViewModel

extension ResetPasswordController: FormViewModel {
    func updateForm() {
        resetButton.backgroundColor = viewModel.buttonBackgroundColor
        resetButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
        resetButton.isEnabled = viewModel.formIsValid
    }
}
