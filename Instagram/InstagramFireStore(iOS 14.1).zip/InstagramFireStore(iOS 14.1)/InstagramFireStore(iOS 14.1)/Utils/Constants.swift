//
//  Constants.swift
//  InstagramFirestoreTutorial (iOS 14.1)
//
//  Created by 승찬 on 2023/04/11.
//

//import FirebaseCore
//import FirebaseFirestore
//import FirebaseAuth
import Firebase

// user 데이터에 접근하는 경로: users -> uid(CurrentUser.uid) -> 데이터
// 그래서 사용자 데이터에 접근할때 마다 Firestore.firestore().collection("users") 을 입력하는 것보다
// 깔끔하게 표현하기 위해 하나의 shortcut키를 만들어서 사용
// collection에 접근하는 것 까지만
let COLLECTION_USERS = Firestore.firestore().collection("users")

let COLLECTION_FOLLOWERS = Firestore.firestore().collection("followers")
let COLLECTION_FOLLOWING = Firestore.firestore().collection("following")

let COLLECTION_POSTS = Firestore.firestore().collection("posts")
let COLLECTION_NOTIFICATIONS = Firestore.firestore().collection("notifications")
