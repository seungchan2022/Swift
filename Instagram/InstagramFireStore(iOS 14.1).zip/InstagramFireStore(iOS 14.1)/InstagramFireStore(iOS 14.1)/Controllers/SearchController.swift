//
//  SearchController.swift
//  InstagramFirestoreTutorial (iOS 14.1)
//
//  Created by 승찬 on 2023/03/31.
//

import UIKit

private let reuseIdentifier = "UserCell"
private let postcellIdentifier = "ProfileCell"

// TableView위에 View에 덮어씌워서
// Search bar 를 누르면 collectionView 띄우고
// Search bar 를 누르지 않으면 tableView 띄운다
class SearchController: UIViewController {
    
    // MARK: - Properties
    
    private let tableView = UITableView()
    private var users = [User]()
    private var posts = [Post]()
    private var filteredUsers = [User]()
    
    // 사용자 검색 가능하게
    private let searchController = UISearchController(searchResultsController: nil)
    
    // 사용자가 활성항태이고 상용자가 그 안에 무언가를 입력한 경우에만 검색 모드로 들어간다.
    private var inSearchMode: Bool {
        return searchController.isActive && !searchController.searchBar.text!.isEmpty
    }
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .white
        // ProfileCell 재사용
        cv.register(ProfileCell.self, forCellWithReuseIdentifier: postcellIdentifier)
        return cv
    }()
    
    // MARK: - Lifetcycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureSearchController()
        configureUI()
        fetchUsers()
        fetchPosts()
    }
    
    // MARK: - API
    
    func fetchUsers() {
        UserService.fetchUsers { users in
            // completion 핸들러가 실행되어야 실행된다
            self.users = users
            self.tableView.reloadData()
        }
    }
    
    // collectionView에 모든 post 표시
    func fetchPosts() {
        PostService.fetchPosts { posts in
            self.posts = posts
            self.collectionView.reloadData()
        }
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        view.backgroundColor = .white
        navigationItem.title = "Explore"
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(UserCell.self, forCellReuseIdentifier: reuseIdentifier)
        tableView.rowHeight = 64
        
        view.addSubview(tableView)
        tableView.fillSuperview()
        tableView.isHidden = true   // 처음에는 collectionView가 보이게
        
        view.addSubview(collectionView)
        collectionView.fillSuperview()
    }
    
    func configureSearchController() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        definesPresentationContext = false
    }
}


// MARK: - UITableViewDataSource

extension SearchController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // 검색 모드가 되면 검색한 것들만 나오고 아니면 모든 사용자가 나온다.
        return inSearchMode ? filteredUsers.count : users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! UserCell
        
        let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]
        cell.viewModel = UserCellViewModel(user: user)
        
        return cell
    }
}

// MARK: UITableViewDelegate

extension SearchController: UITableViewDelegate {
    // 무엇이 선택되었는가? => 원하는 것: 눌렀을때 프로필로 들어가게 하는 것
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]을 추가하지 않으면
        // 검색한다음 아이템을 눌렀을때 검색한 다음에 인덱스가 눌려지는게 아니라
        // 원래 배열의 인덱스에 해당 하는 아이템이 선택되므로 제대로된 인덱스를 넣어주어야 한다.
        let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]
        let controller = ProfileController(user: user )
        navigationController?.pushViewController(controller, animated: true)
    }
}

// MARK: - UISearchBarDelegate

extension SearchController: UISearchBarDelegate {
    // 서치바를 누르면 => tableView가 보이게
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
        collectionView.isHidden = true
        tableView.isHidden = false
    }
    
    // 캔슬을 누르면 => collectionView가 보이게
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        searchBar.showsCancelButton = false
        searchBar.text = nil
        
        collectionView.isHidden = false
        tableView.isHidden = true
    }
}

// MARK: - UISearchResultsUpdating

extension SearchController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
    
        guard let searchText = searchController.searchBar.text?.lowercased() else { return }
        
        // 검색할때 username이나 fullname 중 아무거나 검색해도 결과가 나오게 하기 위해 다음과 같이
        // filteredUsers 라는 프로퍼티를 하나 만들고 넣어준다.
        filteredUsers = users.filter({
            $0.username.contains(searchText) ||
                $0.fullname.lowercased().contains(searchText)
        })
        
        self.tableView.reloadData()
    }
}

// MARK: - UICollectionViewDataSource

extension SearchController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: postcellIdentifier, for: indexPath) as! ProfileCell
        cell.viewModel = PostViewModel(post: posts[indexPath.row])
        
        return cell
    }
}

// MARK: - UICollectionViewDelegate

extension SearchController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let controller = FeedController(collectionViewLayout: UICollectionViewFlowLayout())
        controller.post = posts[indexPath.row]
        navigationController?.pushViewController(controller, animated: true)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout {

// ProfileController에서 가져온것
extension SearchController: UICollectionViewDelegateFlowLayout {
    // 아이템 간의 간격
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    // 줄 간의 간격
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (view.frame.width - 2) / 3
        return CGSize(width: width, height: width)
    }
}
