//
//  FeedController.swift
//  InstagramFirestoreTutorial (iOS 14.1)
//
//  Created by 승찬 on 2023/03/31.
//

import UIKit
//import FirebaseAuth
import Firebase

private let reuseIdentifier = "Cell"

class FeedController: UICollectionViewController {
    
    // MARK: - Properties
    
    private var posts = [Post]() {
        // posts에 데이터가 세팅될 때마다 didSet 수행
        didSet { collectionView.reloadData() }
    }
    
    // 즉, 기본적으로 우리가하고 싶은 것은이 게시자에게 가치가있는 경우에만,
    //  피드에 게시물 1개를 표시합니다.
    //    그렇지 않은 경우 이 모든 소식을 봅니다.
    //  Profile에서 게시물을 눌렀을때 Feed에 모든 게시물이 아닌 누른 게시물만 나오게 하기 위해
    var post: Post? {
        didSet { self.collectionView.reloadData() }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        fetchPosts()
        
        if post != nil {
            checkIfUserLikedPosts()
        }
    }
    
    // MARK: - Actions
    
    @objc func handleRefresh() {
        posts.removeAll()   // => 모두 지우고
        fetchPosts()        // => 데이터 다시 불러오기
    }
    
    @objc func handleLogout() {
        do {
            try Auth.auth().signOut()
            
            // 로그아웃 버튼을 누르면 로그인 페이지가 나타나야 되므로
            let controller = LoginController()
            controller.delegate = self.tabBarController as? MainTabController
            // 로그인화면과 가입화면을 왕래할수 있게 하기 위해 UINavigationController로 설정
            let nav = UINavigationController(rootViewController: controller)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav, animated: true, completion: nil)
        } catch {
            print("DEBUG: Failed to sign out")
        }
    }
    
    // MARK: - API
    
    func fetchPosts() {
        guard post == nil else { return }
        
        //        PostService.fetchPosts { posts in
        //            self.posts = posts
        //            self.collectionView.refreshControl?.endRefreshing()
        //            self.checkIfUserLikedPosts()
        //        }
        
        PostService.fetchFeedPosts { posts in
            self.posts = posts
            self.collectionView.refreshControl?.endRefreshing()
            self.checkIfUserLikedPosts()
        }
    }
    
    func checkIfUserLikedPosts() {
        if let post = post {
            PostService.checkIfUserLikedPost(post: post) { didLike in
                self.post?.didLike = didLike
            }
        } else {
            posts.forEach { post in
                PostService.checkIfUserLikedPost(post: post) { didLike in
                    if let index = self.posts
                        .firstIndex(where: { $0.postId == post.postId }) {
                        self.posts[index].didLike = didLike
                    }
                }
            }
        }
        
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        collectionView.backgroundColor = .white
        
        // 셀을 표현하는 것은 정했지만 컬렉션에 등록하지 않으면 나타나지 않는다.
        collectionView.register(FeedCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        if post == nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "LogOut",
                                                               style: .plain,
                                                               target: self,
                                                               action: #selector(handleLogout))
        }
        
        navigationItem.title = "Feed"
        
        // 새로고침 UI
        let refresher = UIRefreshControl()
        refresher.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        collectionView.refreshControl = refresher
    }
}

// MARK: - UICollectionViewDataSource

// UICollectionViewDataSource는 이미 UICollectionViewController에 준수되었기 때문에 중복으로 준수하지 않아도 된다.
extension FeedController {
    // 몇개의 셀을 표현할 것인가?
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //  Profile에서 게시물을 눌렀을때 Feed에 모든 게시물이 아닌 누른 게시물만 나오게 표현
        return post == nil ? posts.count : 1
    }
    
    // 셀을 어떻게 표현할 것인가?
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! FeedCell
        cell.delegate = self
        
        if let post = post {
            cell.viewModel = PostViewModel(post: post)
        } else {
            // 알맞은 순서에 맞는 post를 나타내기 위해 index 필요
            cell.viewModel = PostViewModel(post: posts[indexPath.row])
        }
        return cell
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension FeedController: UICollectionViewDelegateFlowLayout {
    // 셀 사이즈
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = view.frame.width
        var height = width + 8 + 40 + 8 // 너비 + 프로필이미지와 세이프라인 패딩 8 + 프로필이미지 크기 40 + 프로필이미지와 포스트이미지 패딩 8
        height += 50    // 포스트 이미지 크기
        height += 60    // 포스트 이미지 아래의 버튼, 라벨 등의 크기
        return CGSize(width: width, height: height)
    }
}

// MARK: - FeedCellDelegate

// cell에서  프로토콜을 만들어서 delegate시킨다음 다음 컨트롤러에서 프로토콜을 준수하고 네비게이션 컨트롤사용 ******************************
extension FeedController: FeedCellDelegate {
    func cell(_ cell: FeedCell, wantsToShowProfileFor uid: String) {
        UserService.fetchUser(withUid: uid) { user in
            let controller = ProfileController(user: user)
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func cell(_ cell: FeedCell, wantsToShowCommentsFor post: Post) {
        let controller = CommentController(post: post)
        navigationController?.pushViewController(controller, animated: true)
    }
    
    func cell(_ cell: FeedCell, didLike post: Post) {
        guard let tab = tabBarController as? MainTabController else { return }
        guard let user = tab.user else { return }
        
        //  post에 데이터는 viewModel에 있고 우리가 불러오는 데이터는 viewModel에서 불러오는 것이므로 post.didLike.toggle() 이렇게 적으면 x
        //  => MVVM 형식이기 때문 (view가 model을 가지고있지 않고 model은 vieModel이 가지고 있는 패턴)
        cell.viewModel?.post.didLike.toggle()
        
        if post.didLike {   // didLike가 true일때(좋아요가 눌러진 상태) 누르면 unlike가 되고
            PostService.unlikePost(post: post) { _ in
                cell.likeButton.setImage(UIImage(systemName: "heart"), for: .normal)
                cell.likeButton.tintColor = .black
                cell.viewModel?.post.likes = post.likes - 1
            }
        } else {            // didLike가 false일때 (좋아요가 안눌러신 상태)누르면 like가 된다.
            PostService.likePost(post: post) { _ in
                cell.likeButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                cell.likeButton.tintColor = .red
                cell.viewModel?.post.likes = post.likes + 1
                
                // input parameter의 각각의 의미
                // => 게시물 올린 사람의 id, 누가 알림을 보냈는지, 알림 타입, 특정 게시물
                NotificationService.uploadNotification(toUid: post.ownerUid,
                                                       fromUser: user,
                                                       type: .like,
                                                       post: post)
            }
        }
    }
}
