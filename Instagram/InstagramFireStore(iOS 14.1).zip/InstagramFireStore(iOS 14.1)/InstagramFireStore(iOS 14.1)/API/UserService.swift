//
//  UserService.swift
//  InstagramFirestoreTutorial (iOS 14.1)
//
//  Created by 승찬 on 2023/04/11.
//

// 데이터 베이스에서 사용자에 대한 정보를 검색하기 위해 사용자 개체를 만들어 사용
//import FirebaseAuth
import Firebase

typealias FirestoreCompletion = (Error?) -> Void

struct UserService {
    // user 데이터에 접근하는 경로: users -> uid(CurrentUser.uid) -> 데이터
    // 현재 사용자인 한명의 사용자를 얻는 법
    static func fetchUser(withUid uid: String, completion: @escaping(User) -> Void) {
        COLLECTION_USERS.document(uid).getDocument { snaphshot, error in
            guard let dictionary = snaphshot?.data() else { return }
            
            let user = User(dictionary: dictionary)
            completion(user)
        }
    }
    
    // 모든 사용자를 검색하는 함수
    static func fetchUsers(completion: @escaping([User]) -> Void) {
        COLLECTION_USERS.getDocuments { snapshot, error in
            guard let snapshot = snapshot else { return }
            
//            var users = [User]()    // 모든 사용자를 담을 빈 배열을 만들고
//            snapshot.documents.forEach { document in
//                let user = User(dictionary: document.data())  // 각 유저에 대한 데이터를 불러와서
//                users.append(user)      // 리스트에 넣는다.
//            }
//            completion(users)
            
            // 위의 주석들을 다음의 map 으로 대체 (각각의 유저 데이터의 매핑하겠다)
            let users = snapshot.documents.map { User(dictionary: $0.data()) }
            completion(users)
        }
    }
    
    // follow 하면 following으로 표시됌
    static func follow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).setData([:]) { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).setData([:], completion: completion)
        }
    }
    
    static func unfollow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).delete { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).delete(completion: completion)
        }
        
    }
    
    // follow 버튼을 눌러서 following으로 UI가 업데이트 되지만 다시 나가면 지속되지 않는다.
    // 따라서 사용자의 프로필이 올바른지 확인하기 위해 API 호출을 수행해야 한다.
    static func checkIfUserIsFollowed(uid: String, completion: @escaping(Bool) -> Void) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).getDocument { snapshot, error in
            
            guard let isFollowed = snapshot?.exists else { return }
            completion(isFollowed)
        }
    }
    
    // 실제 following, followers 수 표현
    static func fetchUserStats(uid: String, completion: @escaping(UserStats) -> Void) {
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { (snapshot, _) in
            let followers = snapshot?.documents.count ?? 0
            
            COLLECTION_FOLLOWING.document(uid).collection("user-following").getDocuments { (snapshot, _) in
                let following = snapshot?.documents.count ?? 0
                
                COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid)
                    .getDocuments {(snapshot, _) in
                        
                    let posts = snapshot?.documents.count ?? 0 
                    
                    completion(UserStats(followers: followers, following: following, posts: posts))
                }
                
            }
        }
    }
}

