//
//  AuthService.swift
//  InstagramFirestoreTutorial (iOS 14.1)
//
//  Created by 승찬 on 2023/04/10.
//

import UIKit

//import FirebaseCore
//import FirebaseFirestore
//import FirebaseAuth
import Firebase

// Firebase의 library가 사라짐
typealias SendPasswordResetCallback = (Error?) -> Void

struct AuthCredentials {
    let emial: String
    let password: String
    let fullname: String
    let username: String
    let profileImage: UIImage
}

struct AuthService {
    static func logUserIn(witEmail email: String, password: String, completion: @escaping(AuthDataResult?, Error?) -> Void) {
        
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
    }
    
    static func registerUser(withCredential credentials: AuthCredentials, completion: @escaping(Error?) -> Void) {

        ImageUploader.uploadImage(image: credentials.profileImage) { imageUrl in
            Auth.auth().createUser(withEmail: credentials.emial, password: credentials.password) { (result, error) in

                if let error = error {
                    print("DEBUG: Failed to upload user \(error.localizedDescription)")
                    return
                }

                guard let uid = result?.user.uid else { return }

                let data: [String: Any] = ["email": credentials.emial,
                                           "fullname": credentials.fullname,
                                           "profileImageUrl": imageUrl,
                                           "uid": uid,
                                           "username": credentials.username]

                COLLECTION_USERS.document(uid).setData(data, completion: completion)
            }
        }
    }
    
    static func resetPassword(withEmail email: String,
                              completion: @escaping(SendPasswordResetCallback)) {
        
        Auth.auth().sendPasswordReset(withEmail: email, completion: completion)
    }
}

