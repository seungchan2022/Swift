//
//  ViewController.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/04/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

