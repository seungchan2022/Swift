//
//  Constants.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import Firebase

// 그래서 사용자 데이터에 접근할때 마다 Firestore.firestore().collection("users") 을 입력하는 것보다
// 깔끔하게 표현하기 위해 하나의 shortcut키를 만들어서 사용
// collection에 접근하는 것 까지만 미리 설정하여 사용

// user 데이터에 접근하는 경로: users -> uid(CurrentUser.uid) -> 데이터
let COLLECTION_USERS = Firestore.firestore().collection("users")

let COLLECTION_FOLLOWERS = Firestore.firestore().collection("followers")
let COLLECTION_FOLLOWING = Firestore.firestore().collection("following")

let COLLECTION_POSTS = Firestore.firestore().collection("posts")

let COLLECTION_NOTIFICATIONS = Firestore.firestore().collection("notifications")
