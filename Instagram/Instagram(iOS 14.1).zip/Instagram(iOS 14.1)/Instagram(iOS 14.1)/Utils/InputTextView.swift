//
//  InputTextView.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/04.
//

//TextView를 custom TextView를 만들어서 사용
//Enter caption에 입력하면 placeholder가 사라졌다가 다시 다 지우면 다시 나타남
//customInputView를 클래스 또는 서브 클래스로 할때 재사용 가능

import UIKit

class InputTextView: UITextView {
    
    // MARK: - Properties
    
    var placeholderText: String? {
        didSet { placeholderLabel.text = placeholderText }
    }
    
    let placeholderLabel: UILabel = {
        let label = UILabel()
        label.textColor = .lightGray
        return label
    }()
    
    // TextView의 placeholder의 위치를 다르게 하고 싶음
    // => ????
    var placeholderShouldCenter = true {
        didSet {
            if placeholderShouldCenter {    // => 중앙에 위치 
                placeholderLabel.anchor(left: leftAnchor, right: rightAnchor,
                                        paddingLeft: 8, paddingRight: 8)
                placeholderLabel.centerY(inView: self)
            } else {    // => 맨 위에 위치
                placeholderLabel.anchor(top: topAnchor, left: leftAnchor,
                                        paddingTop: 5, paddingLeft: 7)
            }
        }
    }
    
    // MARK: - Lifecycle
    
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        
        addSubview(placeholderLabel)

        
        // => name: 의 상황이 발생하면(text가 바뀌면) selecter: 의 로직이 실행된다 
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleTextDidChange),
                                               name: UITextView.textDidChangeNotification,
                                               object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Actions
    
    @objc func handleTextDidChange() {
        placeholderLabel.isHidden = !text.isEmpty
    }
}
