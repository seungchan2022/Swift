//
//  AuthService.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import UIKit
import Firebase

// Firebase의 library가 사라짐
typealias SendPasswordResetCallback = (Error?) -> Void

struct AuthCredentials {
    let email: String
    let password: String
    let fullname: String
    let usernmae: String
    let profileImage: UIImage
}

struct AuthService {
    // 로그인
    static func logUserIn(withEmail email: String, password: String,
                          completion: @escaping(AuthDataResult?, Error?) -> Void) {
        
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
    }
    
    
    // 가입한 유저의 데이터를 DB에 넣는 로직
    // 이미지 업로드 -> 업로드 후 다운로드 URL을 받고 -> 유저를 생성하고 -> 유저의 모든 정보를 업로드 한다.
    static func registerUser(withCredential credentials: AuthCredentials, completion: @escaping(Error?) -> Void) {
        
        // 이미지 업로드후 imageUrl에 접근 가능
        ImageUploader.uploadImage(image: credentials.profileImage) { imageUrl in
            Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) { (result, error) in
                
                if let error = error {
                    print("DEBUG: Failed to upload \(error.localizedDescription)")
// return을 작성하는 이유 => error가 발생하면 더이상 다른로직이 실행되지 않게 하기 위해 => error가 발생하면 print하고 return에 의해 코드 실행이 끝남
                    return
                }
                
                // uid를 만들고 => user id
                guard let uid = result?.user.uid else { return }
                
                // uid에 넣을 데이터를 만들고
                let data: [String: Any] = ["email": credentials.email,
                                           "fullname": credentials.fullname,
                                           "profileImageUrl": imageUrl,
                                           "uid": uid,
                                           "username": credentials.usernmae]
                
                // 경로에 맞게 배치
                // Collection (user) -> collection uid -> data
                COLLECTION_USERS.document(uid).setData(data, completion: completion)
            }
        }
    }
    
    // 비밀번호 재설정을 하기 위한 AuthServie 함수 구현
    // 비밀번호를 재설정하기 위해 이메일을 성공적으로 제출했음을 나타내야 합니다.
    static func resetPassword(withEmail email: String, completion: @escaping(SendPasswordResetCallback)) {
        
        Auth.auth().sendPasswordReset(withEmail: email, completion: completion)
    }
}
