//
//  PostService.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/05.
//

import UIKit
import Firebase

struct PostService {
    
    static func uploadPost(caption: String, image: UIImage, user: User,
                           completion: @escaping(FirestoreCompletion)) {
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        // image에 대한 정보를 가져와야 되므로 ImageUploader.uploadImage(=> ImageUploader에서 정의한)를 통해 가져옴
        ImageUploader.uploadImage(image: image) { imageUrl in
            let data = ["caption": caption,
                        "timestamp": Timestamp(date: Date()),
                        "likes": 0,
                        "imageUrl": imageUrl,
                        "ownerUid": uid,
                        "ownerImageUrl": user.profileImageUrl,
                        "ownerUsername": user.username] as [String : Any]
            
            let docRef = COLLECTION_POSTS.addDocument(data: data, completion: completion)
            
            self.updateUserFeedAfterPost(postId: docRef.documentID)
        }
    }
    
    // DB에서 게시물 가져오기 (FeedController에 모든 포스트들이 나오게)
    static func fetchPosts(completion: @escaping([Post]) -> Void) {
        // timestmap를 기준으로 역순으로 정렬(최신것이 제일 먼저 보이도록)
        COLLECTION_POSTS.order(by: "timestamp", descending: true)
            .getDocuments { (snapshot, error) in
                guard let documents = snapshot?.documents else { return }
                
                // UserService의 fetchUsers에서 사용한것과 같음 (map)
                let posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data()) })
                completion(posts)
            }
    }
    
    // 프로필에 들어 갔을때 각 user의 맞는 post들이 나오도록
    static func fetchPosts(forUser uid: String, completion: @escaping([Post]) -> Void) {
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid) // 각 user에 맞게
        
        query.getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else { return }
            
            var posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data()) })
            
            // 게시물 내림차순 정렬 (최근에 올리것이 제일 앞에 게시되게 표현)
            posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds })
            
            completion(posts)
        }
    }
    
    // notfications에서 postImage를 눌렀을때 postId를 통해 post에 대한 Feed를 나오게 하기 위해
    static func fetchPost(withPostId postId: String, completion: @escaping(Post) -> Void) {
        COLLECTION_POSTS.document(postId).getDocument { snapshot, _ in
            
            guard let snapshot = snapshot else { return }
            guard let data = snapshot.data() else { return }
            let post = Post(postId: snapshot.documentID, dictionary: data)
            completion(post)
        }
    }
    
    
    // posts(collection) -> postId(document) -> post-likes(collection) -> 좋아요 누른 사람 id
    // posts에 좋아요를 누르면 user에서 어떤 게시물에 좋아요를 눌렀는지 나온다
    static func likePost(post: Post, completion: @escaping(FirestoreCompletion)) {
        // 현재 로그인한 유저가 좋아요를 누르것 이므로 현재 유저에 대한 uid 필요
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes + 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).setData([:]) { _ in // posts에 좋아요를 누르면 user에서 어떤 게시물에 좋아요를 눌렀는지 나온다
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).setData([:], completion: completion)
        }
    }
    
    static func unlikePost(post: Post, completion: @escaping(FirestoreCompletion)) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard post.likes > 0 else { return }      // 좋아요가 0보다 내려갈 수 X
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes - 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).delete { _ in
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).delete(completion: completion)
        }
    }
    
    // UserService의 checkIfUserIsFollowed와 비슷
    // users -> user id -> user-likes (collection) -> post ID가 존재하면 => 좋아요인 상태
    static func checkIfUserLikedPosts(post: Post, completion: @escaping(Bool) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).getDocument { (snapshot, error) in
            
            guard let didLike = snapshot?.exists else { return }
            completion(didLike)
        }
    }
    
    // (user-feed에 있는 posts를 fetch ⇒ follow되어있는 유저의 postId만 불러오는것)
    static func fetchFeedPosts(completion: @escaping([Post]) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        var posts = [Post]()
        
        // user-feed에 있는 document의 Id를 통해 (postId) 그거에 해당 하는 post를 fetch한다.
        COLLECTION_USERS.document(uid).collection("user-feed").getDocuments { snapshot, error in
            snapshot?.documents.forEach({ document in
                // user-feed에있는 documentID가 postId이다.
                fetchPost(withPostId: document.documentID) { post in
                    posts.append(post)  // posts에 postId 같은 것들을 넣는 느낌?
                    
                    // 게시물 내림차순 정렬 (최근에 올리것이 제일 앞에 게시되게 표현)
                    posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds })
                    
                    completion(posts)
                }
            })
        }
    }
    
    
    // => following한 user의 feed에 대한 정보
    // => 포스트의 ownerUid를 보고 팔로우한 유저면 user-feed에 세팅하기 위해
    // => follow였다가 unfollow로 바뀌면 delete하게 input 파라미터로 didFollow 추가
    static func updateUserFeedAfterFollowing(user: User, didFollow: Bool) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: user.uid)    // 특정 user에 맞게
        
        query.getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else { return }
            
            let docIDs = documents.map({ $0.documentID }) // => 포스트에 대한 정보(docIDs)
            
            // docIDs의 id를 한개씩 돌면서 데이터 세팅
            // users -> user id -> user-feed(collection) -> post에 대한 정보(docIDs)
            docIDs.forEach { id in
                if didFollow {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).setData([:])
                } else {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).delete()
                }
            }
        }
    }
    
    // users -> user id -> user-feed(collection) -> post에 대한 정보
    // => 포스트 업로드후 업로드한 포스트가 follow하는 사람들에게 보이기 위해
    private static func updateUserFeedAfterPost(postId: String) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { snapshot, _ in
            
            guard let documents = snapshot?.documents else { return } // 현재 유저를 팔로우 하는 사람들
            
            documents.forEach { document in
                COLLECTION_USERS.document(document.documentID).collection("user-feed").document(postId).setData([:])      // 팔로우 하는 사람들에게 포스트를 세팅하고
            }
            
            COLLECTION_USERS.document(uid).collection("user-feed").document(postId).setData([:])  // 나의 user-feed또한 업데이트 한다.
        }
    }
}
