//
//  ImageUploader.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import UIKit
import FirebaseStorage

// 이미지 업로드 하는 코드를 작성하여 이미지를 업로드해야 할 때마다 이 코드에 액세스할 수 있도록 한다.

struct ImageUploader {
    static func uploadImage(image: UIImage, completion: @escaping(String) -> Void) {
        guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }
        
        let filename = NSUUID().uuidString
        // 업로드할 경로
        let ref = Storage.storage().reference(withPath: "/profile_images/\(filename)")
        
        // 업로드할 경로를 만든곳에 데이터 넣기
        ref.putData(imageData, metadata: nil) { metadata, error in
            if let error = error {
                print("DEBUG: Failed to upload image \(error.localizedDescription)")
                return
            }
            
            // 위의 로직이 다 수행되고 나서야 아래의 로직(completion)이 수행된다.
            ref.downloadURL { (url, error) in
                guard let imageUrl = url?.absoluteString else { return }
                completion(imageUrl)
            }            
        }
    }
}


