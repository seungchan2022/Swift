//
//  NotificationService.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/11.
//

import Firebase

struct NotificationService {
    
    // input parameter의 각각의 의미
    // => 게시물 올린 사람의 id, 누가 알림을 보냈는지(현재 로그인 되었을때 알림을 보낸사람), 알림 타입, 특정 게시물
    // => post가 nil인 이유: post에 대한 알림(like, post)이 아닌 다른 것에 대한 것(follow)일 수도 있다. => follow는 포스트와 상관 x
    // notifications -> user id -> user-notifications(collection) -> notification id -> data
    static func uploadNotification(toUid uid: String, fromUser: User,
                                   type: NotificationType, post: Post? = nil) {
        
        // currentUid가 필요한 이유: 알림을 보내는 사람은 현재 로그인한 user이다
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        guard uid != currentUid else { return } // 자기자신에 대한 알람은 받지 x
        
        // document id 추가하는 법 ( 문서를 따로 만들어서 -> setData) => notion 정리(대본 56강)
        // notifications => user id => user-notifications(collection) => notification
        let docRef = COLLECTION_NOTIFICATIONS.document(uid).collection("user-notifications").document()
        
        var data: [String: Any] = ["timestamp": Timestamp(date: Date()),
                                   "uid": fromUser.uid,
                                   "type": type.rawValue,
                                   "id": docRef.documentID,
                                   "userProfileImageUrl": fromUser.profileImageUrl,
                                   "username": fromUser.username]
        
        // post에 대한 것이면 추가하므로 위에 data를 var로 설정
        if let post = post {
            data["postId"] = post.postId
            data["postImageUrl"] = post.imageUrl
        }
        
        docRef.setData(data)
    }
    
    static func fetchNotifications(completion: @escaping([Notification]) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let query = COLLECTION_NOTIFICATIONS.document(uid).collection("user-notifications")
            .order(by: "timestamp", descending: true)
        
        query.getDocuments { snapshot, _ in
            guard let documents = snapshot?.documents else { return }
            let notifications = documents.map({ Notification(dictionary: $0.data()) })
            completion(notifications)
        }
    }
}
