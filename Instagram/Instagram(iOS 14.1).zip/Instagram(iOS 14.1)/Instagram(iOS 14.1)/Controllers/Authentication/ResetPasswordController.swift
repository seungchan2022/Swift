//
//  ResetPasswordController.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/13.
//

import UIKit

protocol ResetPasswordControllerDelegate: class {
    func controllerDidSendResetPasswordLink(_ cell: ResetPasswordController)
}

class ResetPasswordController: UIViewController {
    
    // MARK: - Properties
    
    private var viewModel = ResetPasswordViewModel()
    
    var email: String?
    
    weak var delegate: ResetPasswordControllerDelegate?
    
    private let iconImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.image = UIImage(named: "Instagram_logo_white")
        return iv
    }()
    
    private let emailTextField: CustomTextField = {
        let tf = CustomTextField(placeholer: "Email")
        return tf
    }()
    
    private let resetPasswordButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Rest Password", for: .normal)
        button.setTitleColor(UIColor(white: 1, alpha: 0.3), for: .normal)
        button.backgroundColor = .systemPurple.withAlphaComponent(0.5)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.setHeight(50)
        button.isEnabled = false
        button.addTarget(self, action: #selector(handleResetPassword), for: .touchUpInside)
        return button
    }()
    
    private let backButton: UIButton = {
        let button = UIButton(type: .system)
        button.tintColor = .white
        
        // button의 이미지 크기를 설정 하는 법
        //        let imageConfig = UIImage.SymbolConfiguration(pointSize: 30, weight: .light)
        //        let image = UIImage(systemName: "chevron.left", withConfiguration: imageConfig)
        
        let image = UIImage(systemName: "chevron.left")
        button.setImage(image, for: .normal)
        
        button.addTarget(self, action: #selector(handleDismissal), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        configureNotficationObservers()
    }
    
    // MARK: - Actions
    
    @objc func handleResetPassword() {
        guard let email = emailTextField.text else { return }
        
        showLoader(true)
        
        AuthService.resetPassword(withEmail: email) { error in
            self.showLoader(false)
            if let error = error {
//                print("DEBUG: Failed to reset password \(error.localizedDescription)")
                self.showMessage(withTitle: "Error", message: error.localizedDescription)
                return
            }
            self.delegate?.controllerDidSendResetPasswordLink(self)
        }
    }
    
    @objc func handleDismissal() {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func textDidChange(sender: UITextField) {
        if sender == emailTextField {
            viewModel.email = sender.text
        }

        updateForm()
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        configureGradientLayer()
        
        // 로그인 페이지 에서 이메일을 치면 자동으로 리셋 페이지에도 나타나도록 ( var email: String? 프로퍼티 선언)
        emailTextField.text = email
        viewModel.email = email
        updateForm()
        
        view.addSubview(iconImageView)
        iconImageView.setDimensions(height: 80, width: 120)
        iconImageView.centerX(inView: view,
                              topAnchor: view.safeAreaLayoutGuide.topAnchor, paddingTop: 32)
        
        let stack = UIStackView(arrangedSubviews: [emailTextField, resetPasswordButton])
        stack.axis = .vertical
        stack.spacing = 20
        
        view.addSubview(stack)
        stack.anchor(top: iconImageView.bottomAnchor,
                     left: view.leftAnchor, right: view.rightAnchor,
                     paddingTop: 32, paddingLeft: 32, paddingRight: 32)
        
        view.addSubview(backButton)
        backButton.anchor(top: view.safeAreaLayoutGuide.topAnchor,
                          left: view.leftAnchor,
                          paddingTop: 20 ,paddingLeft: 20)
        
    }
    
    func configureNotficationObservers() {
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
    }
}

// MARK: - FormViewModel

extension ResetPasswordController: FormViewModel {
    func updateForm() {
        resetPasswordButton.backgroundColor = viewModel.buttonBackgroundColor
        resetPasswordButton.setTitleColor(viewModel.buttonTitleColor, for: .normal)
        resetPasswordButton.isEnabled = viewModel.formIsValid
    }
}
