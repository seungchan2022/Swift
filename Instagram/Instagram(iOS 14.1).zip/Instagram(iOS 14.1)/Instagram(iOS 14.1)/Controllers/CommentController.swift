//
//  CommentController.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/08.
//

import UIKit

private let reuseIdentifier = "CommentCell"

class CommentController: UICollectionViewController {
    
    // MARK: - Properties
    
    private let post: Post
    private var comments = [Comment]()
    
    //  viewController에 view를 추가 하는 방법 => 직접 추가 => 뷰 컨트롤러가 입력 액세서리 뷰 속성처럼 설정하면 됩니다.
    // => lazy 인 이유: view에 액세스 하려고 하기 위해
    private lazy var commentInputTextView: CommentInputAccessoryView = {
        let frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
        let cv = CommentInputAccessoryView(frame: frame)
        // 일반적으로 cell을 표현하는 곳에 delegate를 추가하는데 여기서는 lazy이므로 여기다 작성?
        cv.delegate = self
        return cv
    }()
    
    // MARK: - Lifecycle
    
    init(post: Post) {
        self.post = post
        super.init(collectionViewLayout: UICollectionViewFlowLayout())
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureCollectionView()
        fetchComments()
    }
    
    // 키보드 숨기기 및 표시
    override var inputAccessoryView: UIView? {
        get { return commentInputTextView }
    }
    
    override var canBecomeFirstResponder: Bool {
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    // MARK: - API
    
    func fetchComments() {
        CommentService.fetchComments(forPost: post.postId) { comments in
            self.comments = comments
            self.collectionView.reloadData()
        }
    }
    
    // MAKR: - Helpers
    
    func configureCollectionView() {
        navigationItem.title = "Comments"
        collectionView.backgroundColor = .white
        
        collectionView.register(CommentCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        // 드래그 하면 키보드가 닫힌다
        collectionView.alwaysBounceVertical = true
        collectionView.keyboardDismissMode = .interactive
    }
}

// MARK: - UICollectionViewDataSource

extension CommentController {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return comments.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CommentCell
        cell.viewModel = CommentViewModel(comment: comments[indexPath.row])
        return cell
    }
}

// MARK: - UICollectionViewDelegate

extension CommentController {
    
    // Comment cell에서 해당 cell을 눌렀을때 해당하는 프로필로 이동하기 위해
    // => fetch할때 있는(fetchComments) 각 comment의 uid 사용
    // => comment의 uid를 이용하여 DB의 users의 data에 접근 한다 (fetchUser이용)
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let uid = comments[indexPath.row].uid   // comment uid
//        print("DEBUG: Comment uid is \(uid)")
        UserService.fetchUser(withUid: uid) { user in   // 그 uid를 가지고 user의 접근하여
            let controller = ProfileController(user: user)  // 각 user에 해당하는 프로필이 나오도록
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension CommentController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let viewModel = CommentViewModel(comment: comments[indexPath.row])
        // text 길이에 따라 각 cell의 높이가 달라짐
        let height = viewModel.size(forWidth: view.frame.width).height + 32 // 32:spacing
        return CGSize(width: view.frame.width, height: height)
    }
}

// MARK: - CommentInputAccessoryViewDelegate

extension CommentController: CommentInputAccessoryViewDelegate {
    func inputView(_ inputView: CommentInputAccessoryView, wantsToUploadComment comment: String) {

        // tabBarController 에서 user를 얻는 방법
        // => user에 대한 것을 maintab에서 가져오는 이유 이해 X
        // => user를 불러오는 API (fetchUser)가 MainTabController에 있기 때문?
        guard let tab = tabBarController as? MainTabController else { return }
        guard let currentUser = tab.user else { return }
        
        showLoader(true)
        
        CommentService.uploadComment(comment: comment, postID: post.postId, user: currentUser) { error in
            
            self.showLoader(false)
            
            inputView.clearCommentTextView()
            
            NotificationService.uploadNotification(toUid: self.post.ownerUid,
                                                   fromUser: currentUser,
                                                   type: .comment, post: self.post)
        }
    }
}
