//
//  MainTabController.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import UIKit
import Firebase
import YPImagePicker

class MainTabController: UITabBarController {
    
    // MARK: - Properties
    
    var user: User? {
        didSet {
            guard let user = user else { return }
            configureViewControllers(withUser: user) // => 세팅이 되면 호출
        }
    }
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkIfUserLoggedIn()
        fetchUser()
    }
    
    // MARK: - API
    
    // MainTab에서 user를 fetch하고 각 viewController에서는 init을 통해서 => ?
    // Tabbaa 컨트롤러에서 사용자를 검색한 다음 View Controller를 초기화합니다.
    func fetchUser() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        UserService.fetchUser(withUid: uid) { user in
            self.user = user
        }
    }
    
    // 로그인이 되었으면 바로 메인뷰를 보여주고 로그인이 안된 상태라면 로그인 화면을 보여주기 위해
    func checkIfUserLoggedIn() {
        if Auth.auth().currentUser == nil {
            DispatchQueue.main.async {
                let controller = LoginController()
                
                // 오직 MainTabController가 delegate 프로토콜을 준수하기 때문에 self로 설정 나머지는 x => 올바른 사용자가 로그인 되었는지
                controller.delegate = self
                
                // 로그인화면과 가입화면을 왕래할수 있게 하기 위해 UINavigationController로 설정
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: true, completion: nil)
            }
        }
    }
    
    // MARK: - Helpers
    
    // input 파라미터를 넣는 이유: ProfileController의 user는 옵셔널이 아니지만 MainTab의 user 옵셔널이므로
    func configureViewControllers(withUser user: User) {
        view.backgroundColor = .white
        self.delegate = self
        
        // UICollectionViewLayout으로 작성하면 오류남 => 많이 하는 실수 !!
        let layout = UICollectionViewFlowLayout()
        let feed = configureTabBarItemImage(unselected: UIImage(named: "home_unselected")!, selected: UIImage (named: "home_selected")!, rootViewController: FeedController(collectionViewLayout: layout))
        
        let search = configureTabBarItemImage(unselected: UIImage(named: "search_unselected")!, selected: UIImage(named: "search_selected")!, rootViewController: SearchController())
        
        let imageSelector = configureTabBarItemImage(unselected: UIImage(named: "plus_unselected")!, selected: UIImage(named: "plus_unselected")!, rootViewController: ImageSelectorController())
        
        let notification = configureTabBarItemImage(unselected: UIImage(named: "like_unselected")!, selected: UIImage(named: "like_selected")!, rootViewController: NotificationController())
        
        let profileController = ProfileController(user: user)
        let profile = configureTabBarItemImage(unselected: UIImage(named: "profile_unselected")!, selected: UIImage(named: "profile_selected")!, rootViewController: profileController)
        
        viewControllers = [feed, search, imageSelector, notification, profile]
        
        tabBar.tintColor = .black
    }
    
    func configureTabBarItemImage(unselected: UIImage, selected: UIImage, rootViewController: UIViewController) -> UINavigationController {
        
        let nav = UINavigationController(rootViewController: rootViewController)
        nav.tabBarItem.image = unselected
        nav.tabBarItem.selectedImage = selected
        nav.navigationBar.tintColor = .black
 
        return nav
    }
    
    // 이미지 선택후 실행할 로직
    func didFinishPickingMedia(_ picker: YPImagePicker) {
        picker.didFinishPicking { items, _ in
            picker.dismiss(animated: false) {
                
                // 선택한 이미지를 가지고 와야된다
                guard let selectedImage = items.singlePhoto?.image else { return }
                
                let controller = UploadPostController()
                // 선택한 이미지가 나오도록
                controller.selectedImage = selectedImage
                controller.delegate = self
                
                // 현재 로그인한 유저가 게시물을 업로드
                controller.currentUser = self.user
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: false, completion: nil)
            }
        }
    }
}

// MARK: - AuthenticationDelegate

extension MainTabController: AuthenticationDelegate {
    func authenticationDidComplete() {
        fetchUser()
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITabBarControllerDelegate

extension MainTabController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        // index가 필요한 이유: MainTab에서 어떤 viewController를 선택했을때 이미지를 선택하는 메서드를 실행해야 되는지 알아야 하기 위해
        let index = viewControllers?.firstIndex(of: viewController)
        
        if index == 2 {
            var config = YPImagePickerConfiguration()
            config.library.mediaType = .photo
            config.shouldSaveNewPicturesToAlbum = false
            config.startOnScreen = .library
            config.screens = [.library]
            config.hidesStatusBar = false
            config.hidesBottomBar = false
            config.library.maxNumberOfItems = 1
            
            let picker = YPImagePicker(configuration: config)
            picker.modalPresentationStyle = .fullScreen
            present(picker, animated: true, completion: nil)
            
            didFinishPickingMedia(picker)
        }
        
        return true
    }
}

// MARK: - UploadPostControllerDelegate

extension MainTabController: UploadPostControllerDelegate {
    
    // 이미지 포스트후 화면이 FeedController를 띄어줘야 된다.
    func controllerDidFinishUploadingPost(_ controller: UploadPostController) {
        selectedIndex = 0
        controller.dismiss(animated: true, completion: nil)
        
        // 이미지 업로드후 업로드한 데이터가 바로 FeedController에 업로드된 상태로 나타나야 한다.
        // => viewControllers를 사용하여 Tabbar의 각 viewController에 접근할 수 있다.
        // => MainTab에 있는 viewController들은 UINavigationController이므로 주의 필요
        // => UINavigationController를 찾고 FeedController를 찾고 FeedController에서 작성했던 handleRefresh 사용 (업데이트를 하여 화면에 게시물이 나오도록)
        // => ??
        guard let feedNav = viewControllers?.first as? UINavigationController else { return }
        guard let feed = feedNav.viewControllers.first as? FeedController else { return }
        feed.handleRefresh()
    }
}
