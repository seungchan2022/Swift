//
//  ImageSelector.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import UIKit

class ImageSelectorController: UIViewController {
    
    // MARK: - Properties
    
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
    }
}
