//
//  SearchController.swift
//  Instagram(iOS 14.1)
//
//  Created by 승찬 on 2023/05/01.
//

import UIKit

private let reuseIdentifier = "UserCell"
private let postcellIdentifier = "ProfileCell"

// TableView위에 View에 덮어씌워서
// Search bar 를 누르면 collectionView 띄우고
// Search bar 를 누르지 않으면 tableView 띄운다
class SearchController: UIViewController {
    
    // MARK: - Properties
    
    private let tableView = UITableView()
    
    // user를 넣을 리스트 만들기
    private var users = [User]()
    private var filteredUsers = [User]()
    
    private var posts = [Post]()
    
    private let searchController = UISearchController(searchResultsController: nil)
    
    // 사용자가 활성상태이고 사용자가 그 안에 무언가를 입력한 경우에만 검색 모드로 들어간다.
    private var inSearchMode: Bool {
        return searchController.isActive && !searchController.searchBar.text!.isEmpty
    }
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .white
        cv.register(ProfileCell.self, forCellWithReuseIdentifier: postcellIdentifier)
        return cv
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureSearchController()
        configureUI()
        fetchUsers()
        fetchPosts()
    }
    
    // MARK: - API
    
    func fetchUsers() {
        // => completion이 성공할때 마다 users에 user가 들어가고 reload 하고 user의 개수만큼 다시 추가되는 방식
        UserService.fetchUsers { users in
            self.users = users
            // reloadData를 사용해 UITableViewDataSource의 함수를 다시 작동 시켜 비어있는 배열(users)에 추가하는 방식
            self.tableView.reloadData()
        }
    }
    
    func fetchPosts() {
        PostService.fetchPosts { posts in
            self.posts = posts
            self.collectionView.reloadData()
        }
    }
    
    // MARK: - Helpers
    
    func configureUI() {
        view.backgroundColor = .white
        navigationItem.title = "Explore"
        
        tableView.delegate = self
        tableView.dataSource = self
        
        // UITableViewController는 앞에 collectionView가 아닌 tableView가 붙어야한다.
        tableView.register(UserCell.self, forCellReuseIdentifier: reuseIdentifier)
        tableView.rowHeight = 60
        
        view.addSubview(tableView)
        tableView.fillSuperview()
        
        tableView.isHidden = true   // 처음에는 collectionView가 보이도록
        
        view.addSubview(collectionView)
        collectionView.fillSuperview()
    }
    
    func configureSearchController() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        definesPresentationContext = false
    }
}

// MARK: - UITableViewDataSource

extension SearchController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // 검색 모드가 되면 검색한 것들만 나오고 아니면 모든 사용자가 나온다.
        return inSearchMode ? filteredUsers.count : users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! UserCell
        
        let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]
        // 리스트에 접근할 인덱스 필요
        cell.viewModel = UserCellViewModel(user: user)
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension SearchController: UITableViewDelegate {
    // => searchController가 UITableView에서 UIView로 바뀌었으므로 더 이상 override할 superclass가 없어졌으므로 tableview에 관한 전부 override를 지운다. => 그다음 superClass가 없어졌으므로 프로토콜을 준수해야한다. (원래는 상속되었는데)
    // 셀을 눌렀을때 해당 user의 프로필로 들어가도록
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // 이렇게 해주지 않으면 원래 있던 순서의 사용자로 들어가게 된다.
        // ex) 1: joker ,2: spiderman
        //      => search: s => spiderman이 첫번째로 나오는데 이걸 클릭하면 joker 프로필이 나옴
        //      => 그래서 인덱스를 다시 설정해주어야 된다.
        
        // let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]을 추가하지 않으면
        // 검색한다음 아이템을 눌렀을때 검색한 다음에 인덱스가 눌려지는게 아니라
        // 원래 배열의 인덱스에 해당 하는 아이템이 선택되므로 제대로된 인덱스를 넣어주어야 한다.
        let user = inSearchMode ? filteredUsers[indexPath.row] : users[indexPath.row]
        
        let controller = ProfileController(user: user)
        navigationController?.pushViewController(controller, animated: true)
    }
}

// MARK: - UISearchResultsUpdating

extension SearchController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        
        guard let searchText = searchController.searchBar.text?.lowercased() else { return }
        
        // 검색할때 username이나 fullname 중 아무거나 검색해도 결과가 나오게 하기 위해 다음과 같이
        // filteredUsers 라는 프로퍼티를 하나 만들고 넣어준다.
        filteredUsers = users.filter({
            $0.username.contains(searchText)
            || $0.fullname.lowercased().contains(searchText)
        })
        
        self.tableView.reloadData()
    }
}

// MARK: - UISearchBarDelegate

extension SearchController: UISearchBarDelegate {
    // 서치바를 누르면 => tableView가 보이게
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
        collectionView.isHidden = true
        tableView.isHidden = false
    }
    
    // 캔슬을 누르면 => collectionView가 보이게
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        searchBar.showsCancelButton = false
        searchBar.text = nil        // cancel 버튼을 누르면 글자가 지워진다.
        
        collectionView.isHidden = false
        tableView.isHidden = true
    }
}


// MARK: - UICollectionViewDataSource

extension SearchController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: postcellIdentifier, for: indexPath) as! ProfileCell
        
        cell.viewModel = PostViewModel(post: posts[indexPath.row])
        return cell
    }
    
}

// MARK: - UICollectionViewDelegate

extension SearchController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let controller = FeedController(collectionViewLayout: UICollectionViewFlowLayout())
        controller.post = posts[indexPath.row]
        navigationController?.pushViewController(controller, animated: true)
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension SearchController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (view.frame.width - 2) / 3
        return CGSize(width: width, height: width)
    }
}


