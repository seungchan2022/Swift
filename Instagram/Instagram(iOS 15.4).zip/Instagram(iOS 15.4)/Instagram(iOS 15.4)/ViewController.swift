//
//  ViewController.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/04/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}



