//
//  UserService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/04/24.
//

import Firebase

typealias FirestoreCompletion = (Error?) -> Void

struct UserService {
    // 현재 사용자의 데이터를 가져오는 함수
    static func fetchUser(completion: @escaping(User) -> Void) {
        // users -> uid -> data
        guard let uid = Auth.auth().currentUser?.uid else { return }
        COLLECTION_USERS.document(uid).getDocument { snapshot, error in
            
            guard let dictionary = snapshot?.data() else { return }
            
            let user = User(dictionary: dictionary)
            completion(user)
        }
    }
    
    // 모든 사용자의 데이터를 가져오는 함수 => SearchController에서 모든 사용자를 표현하기 위해
    static func fetchUsers(completion: @escaping([User]) -> Void) {
        COLLECTION_USERS.getDocuments { (snapshot, error) in
            guard let snapshot = snapshot else { return }

//            var users = [User]()    // 모든 사용자를 담을 빈 배열을 만들고
//            snapshot.documents.forEach { document in
            // 각 유저에 대한 데이터를 불러와서
//                let user = User(dictionary: document.data())
//                users.append(user)      // 리스트에 넣는다.
//            }
//            completion(users)

            // 위의 주석들을 다음의 map 으로 대체 (각각의 유저 데이터의 매핑하겠다)
            let users = snapshot.documents.map({ User(dictionary: $0.data()) })
            completion(users)
        }
    }
    
    // following -> currentuseruid -> "user-following" -> uid
    static func follow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).setData([:]) { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).setData([:], completion: completion)
        }
    }
    
    static func unfollow(uid: String, completion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).delete { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).delete(completion: completion)
        }
    }
    
    // follow 버튼을 눌러서 following으로 UI가 업데이트 되지만 다시 나가면 지속되지 않는다.
    // 따라서 사용자의 프로필이 올바른지 확인하기 위해 API 호출을 수행해야 한다.
    static func checkIfUserIsFollowed(uid: String, completion: @escaping(Bool) -> Void) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).getDocument { (snapshot, error) in
            
            // snapshot이 존재하면 following한 상황이므로 following으로 UI가 지속되어야 한다.
            guard let isFollowed = snapshot?.exists else { return }
            completion(isFollowed)
        }
    }
    
    // 실제 following, followers, posts 수 표현
    static func fetchUserStats(uid: String, completion: @escaping(UserStats) -> Void) {
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { (snapshot, _) in
            
            let followers = snapshot?.documents.count ?? 0
            
            COLLECTION_FOLLOWING.document(uid).collection("user-following").getDocuments { (snapshot, _) in
                let following = snapshot?.documents.count ?? 0
                
                COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid).getDocuments { (snapshot, _) in
                    let posts = snapshot?.documents.count ?? 0
                    
                    completion(UserStats(following: following, followers: followers, posts: posts))
                }
            }
        }
    }
}
