//
//  AuthService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/04/23.
//

import UIKit
import Firebase

struct AuthCredentials {
    let email: String
    let password: String
    let fullname: String
    let username: String
    let profileImage: UIImage
}

struct AuthService {
    static func logUserIn(withEmail email: String, password: String, completion: @escaping(AuthDataResult?, Error?) -> Void) {
        
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
    }
    
    // 이미지 업로드 -> 업로드 후 다운로드 URL을 받고 -> 모든 유저 정보를 업로드 한다.
    static func registerUser(withCredentials credentials: AuthCredentials, completion: @escaping(Error?) -> Void) {
        
        // 이미지 업로드후 imageUrl에 접근 가능
        ImageUploader.uploadImage(image: credentials.profileImage) { imageUrl in
            Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) { (result, error) in
                if let error = error {
                    print("DEBUG: Failed to register user \(error.localizedDescription)")
                    return
                }
                
                // uid를 만들고
                guard let uid = result?.user.uid else { return }
                
                // uid에 넣을 데이터 만들고
                let data: [String: Any] = ["email": credentials.email,
                                           "fullname": credentials.fullname,
                                           "username": credentials.username,
                                           "profileImageUrl": imageUrl,
                                           "uid": uid]
                
                // 경로에 맞게 설정
                COLLECTION_USERS.document(uid).setData(data, completion: completion)
            }
        }
    }
}
