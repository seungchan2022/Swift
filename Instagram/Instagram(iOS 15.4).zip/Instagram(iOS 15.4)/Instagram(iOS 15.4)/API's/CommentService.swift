//
//  CommentService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/09.
//

import Firebase

struct CommentService {
    
    // comment를 DB에 upload
    // post -> post ID -> comments(collection) -> data
    static func uploadComment(comment: String, postID: String, user: User, completion: @escaping(FirestoreCompletion)) {
        
        let data: [String: Any] = ["comment": comment,
                                   "profileImageUrl": user.profileImageUrl,
                                   "timestamp": Timestamp(date: Date()),
                                   "uid": user.uid,
                                   "username": user.username]
        
        // post ID에 comments추가
        COLLECTION_POSTS.document(postID).collection("comments").addDocument(data: data, completion: completion)
    }
    
    // post에 대해 comment를 다는것이므로 각 포스트에 대한 postID 필요
    static func fetchComments(forPost postID: String,
                              completion: @escaping([Comment]) -> Void) {
        
        var comments = [Comment]()
        let query = COLLECTION_POSTS.document(postID).collection("comments").order(by: "timestamp", descending: true)
        
        query.addSnapshotListener { (snapshot, error) in
            snapshot?.documentChanges.forEach({ change in   // document가 변경이 되면 루프를 도는데
                if change.type == .added {   // type이 추가되는 거면 아래와 같은 로직 수행
                    let data = change.document.data()
                    let comment = Comment(dictionary: data)
                    comments.append(comment)
                }
            })
            
            completion(comments)
            
        }
    }
}

/*
 
 addSnapshotListener => firebase 함수
 
 -> fetchComments 수행과정에 대한 설명
 
 스냅샷 리스너에서 쿼리를 실행합니다.
 그래서 스냅샷.
  그리고 모두가 우리가이 어드비 스너를하는 이유는이 사람이 리스너를 연결한다고 말하는 것을 확인합시다.
 스냅샷 이벤트용.
 즉, 기본적으로 이것이 행하는 것은, 이 공통 구조에 무언가가 추가될 때마다,
 이러한 이벤트를 수신하고 이벤트를 기반으로 UI를 업데이트할 수 있습니다.
 리스너.
 따라서 구조에 주석이 추가되고 주석 데이터가 업데이트됩니다.
 따라서, 데이터베이스 구조의 그 청취자에 의해, UI 를 그것으로 갱신할 수가 있습니다.
 수동으로 API 호출을 실행하는 대신 데이터베이스에 추가되는 즉시 새 주석
 게시물과 마찬가지로 데이터를 업데이트합니다.
 새 게시물을 보려면 드롭다운하고 업데이트하고 API 호출을 수동으로 실행해야 합니다.
 이렇게 하면 해당 데이터베이스 구조에 스냅샷 리스너가 추가되므로 UI를 기본적으로 즉시 업데이트할 수 있습니다.
 그 안의 메시징 기능과 매우 비슷합니다.
 */
