//
//  UserService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/04.
//

import UIKit
import Firebase

typealias FirestoreCompletion = (Error?) -> Void

// 데이터 베이스에서 사용자에 대한 정보를 가져오기 위해 사용자 개체를 만들어 사용
struct UserService {
    
    // 현재 User의 데이터 정보를 얻는 함수
    // => input 파라미터로 uid 넣은 이유: CommentController의 UICollectionViewDelegate 설명 확인(user의 uid를 통해 프로필 정보를 가져온다)
    static func fetchUser(withUid uid: String, completion: @escaping(User) -> Void) {
        
        COLLECTION_USERS.document(uid).getDocument { snapshot, error in
            guard let dictionary = snapshot?.data() else { return }
//            print("DEBUG: Snapshot is \(snapshot?.data())")
            
            let users = User(dictionary: dictionary)
            
            completion(users)
        }
    }
    
    
    // 모든 사용자의 데이터를 얻는 함수 (DB에 있는 모든 유저들을 fetch하여 SearchController 리스트에 모두 나오도록)
    static func fetchUsers(completion: @escaping([User]) -> Void) {
        COLLECTION_USERS.getDocuments { (snapshot, error) in
            guard let snapshot = snapshot else { return }
            
//            var users = [User]() // 빈 배열을 만들고
//            snapshot.documents.forEach { document in  // snapshot의 document에 접근
////                print("DEBUG: Document in service file \(document.data())")
//                let user = User(dictionary: document.data())    // 각 유저에 대한 데이터를 불러와서
//                users.append(user)  // 배열에 모든 데이터를 넣는다.
//            }
//            completion(users)
            
            // 위의 주석들을 다음의 map 으로 대체 (각각의 유저 데이터의 매핑하겠다) *****
            let users = snapshot.documents.map({ User(dictionary: $0.data()) })
            
            completion(users)
        }
    }

    //    following -> currentUser uid -> user-following(doc) -> following uid(follow당한사람)
        // follow 하면 following으로 표시됌
    static func follow(uid: String, compeltion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).setData([:]) { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(currentUid).setData([:], completion: compeltion)
        }
    }
    
    static func unfollow(uid: String, compeltion: @escaping(FirestoreCompletion)) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).delete { error in
            
            COLLECTION_FOLLOWERS.document(uid).collection("user-followers").document(uid).delete(completion: compeltion)
        }
    }
    
    // follow 버튼을 눌러서 following으로 UI가 업데이트 되지만 다시 나가면 지속되지 않는다.
    // 따라서 사용자의 프로필이 올바른지 확인하기 위해 API 호출을 수행해야 한다.
    static func checkIfUserIsFollowed(uid: String, completion: @escaping(Bool) -> Void) {
        guard let currentUid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWING.document(currentUid).collection("user-following").document(uid).getDocument { (snapshot, error) in
            
            // snapshot?.exists의 값은 Bool이다 => follow가 제대로 되었는지 아닌지 확인하기 위해 (true or false) => 존재하면 follow 했다는 의미이므로 Following으로 계속 표시되게
            guard let isFollowed = snapshot?.exists else { return }
            completion(isFollowed)
        }
    }
    
    // 실제 followers, following 수 표현
    static func fetchUserStats(uid: String, completion: @escaping(UserStats) -> Void) {
        
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { (snapshot, _) in
            let followers = snapshot?.documents.count ?? 0
            
            COLLECTION_FOLLOWING.document(uid).collection("user-following").getDocuments { (snapshot, _) in
                let following = snapshot?.documents.count ?? 0
                
                COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid).getDocuments { (snapshot, _) in
                    let posts = snapshot?.documents.count ?? 0
                    
                    completion(UserStats(followers: followers, following: following, posts: posts))
                }
            }
        }
    }
}
