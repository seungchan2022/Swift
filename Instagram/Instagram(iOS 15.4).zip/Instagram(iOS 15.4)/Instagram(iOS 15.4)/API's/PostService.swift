//
//  PostService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/06.
//

import UIKit
import Firebase

struct PostService {
    
    // DB에 포스트 업로드
    static func uploadPost(caption: String, image: UIImage, user: User, completion: @escaping(FirestoreCompletion)) {
        
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        ImageUploader.uploadImage(image: image) { imageUrl in
            let data = ["caption": caption,
                        "timestamp": Timestamp(date: Date()),
                        "likes": 0,
                        "imageUrl": imageUrl,
                        "ownerUid": uid,
                        "ownerUsername": user.username,
                        "ownerImageUrl": user.profileImageUrl] as [String : Any]
            
            let docRef = COLLECTION_POSTS.addDocument(data: data, completion: completion)
            
            self.updateUserFeedAfterPost(postId: docRef.documentID)
        }
    }
    
    // DB에 있는 모드 포스트를 fetch => Feed에 나타내기 위해
    static func fetchPosts(completion: @escaping([Post]) -> Void) {
        COLLECTION_POSTS.order(by: "timestamp", descending: true).getDocuments { (snapshot, error) in
            
            guard let documents = snapshot?.documents else { return }
            
            let posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data()) })
            completion(posts)
        }
    }
    
    // 프로필에 들어 갔을때 각 user의 맞는 post들이 나오도록
    static func fetchPosts(forUser uid: String, completion: @escaping([Post]) -> Void) {
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: uid) // 각 user에 맞게
        
        query.getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else { return }
            
            var posts = documents.map({ Post(postId: $0.documentID, dictionary: $0.data()) })
            
            // 최신것이 앞으로 오게
            posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds })
            completion(posts)
        }
    }
    
    // postId를 통해 post를 fetch할 수 있도록 => 하나의 feed만 나오도록 => (Post) => 위와 비교
    static func fetchPost(withPostId postId: String, completion: @escaping(Post) -> Void) {
        COLLECTION_POSTS.document(postId).getDocument { snapshot, _ in

            guard let snapshot = snapshot else { return }
            guard let data = snapshot.data() else { return }
            let post = Post(postId: snapshot.documentID, dictionary: data)
            completion(post)
        }
    }
    
    // 좋아요를 누른 유저의 id만 필요 => 좋아요를 누르는 사람은 현재 로그인된 user
    // posts -> postID -> post-likes(collection) -> 좋아요를 누른 사람의 id
    static func likePosts(post: Post, completion: @escaping(FirestoreCompletion)) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes + 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).setData([:]) { _ in
            // posts에 좋아요를 누르면 user에서 어떤 게시물에 좋아요를 눌렀는지 나온다
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).setData([:], completion: completion)
        }
    }
    
    // likePosts와 반대
    static func unlikePosts(post: Post, completion: @escaping(FirestoreCompletion)) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard post.likes > 0 else { return }    // 좋아요는 0보다 작을 수 X
        
        COLLECTION_POSTS.document(post.postId).updateData(["likes": post.likes - 1])
        
        COLLECTION_POSTS.document(post.postId).collection("post-likes").document(uid).delete { _ in
            COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).delete(completion: completion)
        }
    }
    
    // UserService의 checkIfUserIsFollowed와 비슷
    // users -> user id -> user-likes (collection) -> post ID가 존재하면 => 좋아요인 상태
    static func checkIfUserLikedPosts(post: Post, completion: @escaping(Bool) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_USERS.document(uid).collection("user-likes").document(post.postId).getDocument { (snapshot, error) in
            
            guard let didLike = snapshot?.exists else { return }
            completion(didLike)
        }
    }
    
    // (user-feed에 있는 posts를 fetch ⇒ follow되어있는 유저의 postId만 불러오는것)
    static func fetchFeedPosts(completion: @escaping([Post]) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        var posts = [Post]()
        
        // user-feed에 있는 document의 Id를 통해 (postId) 그거에 해당 하는 post를 fetch한다.
        COLLECTION_USERS.document(uid).collection("user-feed").getDocuments { snapshot, _ in
            snapshot?.documents.forEach({ document in
                // user-feed에있는 documentID가 postId이다.
                fetchPost(withPostId: document.documentID) { post in
                    posts.append(post)
                    
                    // 최신것이 앞으로 오게
                    posts.sort(by: { $0.timestamp.seconds > $1.timestamp.seconds })
                    completion(posts)
                }
            })
        }
    }
    
    // => following한 user의 feed에 대한 정보
    // follow였다가 unfollow로 바뀌면 delete하게 input 파라미터로 didFollow 추가
    // => 포스트의 ownerUid를 보고 팔로우한 유저면 user-feed에 세팅하기 위해
    static func updateUserFeedAfterFollowing(user: User, didFollow: Bool) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let query = COLLECTION_POSTS.whereField("ownerUid", isEqualTo: user.uid)  // 특정 유저
        
        query.getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else { return }
            
            let docIDs = documents.map({ $0.documentID })   // => post에 대한 정보
            
            // users -> user id -> user-feed(collection) -> post에 대한 정보(docIDs)
            // docIDs의 id를 한개씩 돌면서 데이터 세팅
            docIDs.forEach { id in
                if didFollow {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).setData([:])
                } else {
                    COLLECTION_USERS.document(uid).collection("user-feed").document(id).delete()
                }
            }
        }
    }
    
//    updateUserFeedAfterPost   => uploadPost에 추가
//    (새로운 이미지 업로드후 팔로우 하는 사람들이 보이도록 세팅)
//    (현재 유저를 follow하는 user의 데이터를 얻는다→ 팔로우 하는 사람들에게 포스트를 세팅하고 → 나의 user-feed 도 설정)
    private static func updateUserFeedAfterPost(postId: String) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        COLLECTION_FOLLOWERS.document(uid).collection("user-followers").getDocuments { snapshot, _ in
            
            // 현재 유저를 팔로우 하는 사람들
            guard let documents = snapshot?.documents else { return }
            
            documents.forEach { document in
                COLLECTION_USERS.document(document.documentID).collection("user-feed").document(postId).setData([:])
            }
            
            // 현재 user의 user-feed도 업데이트 해준다 => 이해 x
            COLLECTION_POSTS.document(uid).collection("user-feed").document(postId).setData([:])
        }
    }
}
