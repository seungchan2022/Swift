//
//  AuthService.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/02.
//

import UIKit
import Firebase

typealias SendPasswordResetCallback = (Error?) -> Void

struct AuthCredentials {
    let email: String
    let password: String
    let fullname: String
    let username: String
    let profileImage: UIImage
}

struct AuthService {
    static func logUserIn(withEmail email: String, password: String, completion: @escaping(AuthDataResult?, Error?) -> Void) {
        
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
    }
    
    // 가입한 유저의 데이터를 DB에 넣는 로직
    // 이미지 업로드 -> 업로드 후 다운로드 URL을 받고 -> 유저를 생성하고 -> 유저의 모든 정보를 업로드 한다.
    static func registerUser(withCredential credentials: AuthCredentials,
                             completion: @escaping(Error?) -> Void) {
        
        ImageUploader.uploadImage(image: credentials.profileImage) { imageUrl in
            Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) { (result, error) in
                
                if let error = error {
                    print("DEBUG: Failed to register user \(error.localizedDescription)")
                    return  // 에러가 발생하면 여기서 끝나게
                }
                
                // uid를 만들고
                guard let uid = result?.user.uid else { return }
                
                // uid에 넣을 데이터를 만들고
                let data: [String: Any] = ["email": credentials.email,
                                           "fullname": credentials.fullname,
                                           "profileImageUrl": imageUrl,
                                           "uid": uid,
                                           "username": credentials.username]
                
                // 경로에 맞게 데이터 설정
                COLLECTION_USERS.document(uid).setData(data, completion: completion)
            }
        }
    }
    
    // 비밀번호를 재설정하기 위해 이메일을 성공적으로 제출했음을 나타내야 합니다.
    static func resetPassword(withEmail email: String, completion: @escaping(SendPasswordResetCallback)) {
        
        Auth.auth().sendPasswordReset(withEmail: email, completion: completion)
    }
}
