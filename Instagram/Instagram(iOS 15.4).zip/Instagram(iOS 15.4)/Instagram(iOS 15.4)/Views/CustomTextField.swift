//
//  CustomTextFiedl.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/02.
//

import UIKit

class CustomTextField: UITextField {
    
    init(placeholder: String) {
        super.init(frame: .zero)
        
        // 공백 넣기
        let spacer = UIView()
        spacer.setDimensions(height: 50, width: 10)
        leftView = spacer
        leftViewMode = .always
        
        borderStyle = .none
        textColor = .white       // 입력하는 텍스트
        keyboardAppearance = .dark
        setHeight(50)
        backgroundColor = UIColor(white: 1, alpha: 0.1)  // 상자의 배경
        attributedPlaceholder = NSAttributedString(string: placeholder,
                                                   attributes: [.font: UIFont.systemFont(ofSize: 15),
                                                    .foregroundColor: UIColor(white: 1, alpha: 0.5)])

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
