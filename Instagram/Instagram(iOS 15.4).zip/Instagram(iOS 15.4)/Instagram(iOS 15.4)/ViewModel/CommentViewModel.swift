//
//  CommentViewModel.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/09.
//

import UIKit

struct CommentViewModel {
    private let comment: Comment
    
    var profileImageUrl: URL? { return URL(string: comment.profileImageUrl) }
    
    init(comment: Comment) {
        self.comment = comment
    }
    
    func commentLabelText() -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: "\(comment.username)  ",
                                                         attributes: [.font: UIFont.boldSystemFont(ofSize: 14)])
        attributedString.append(NSAttributedString(string: comment.commentText,
                                                   attributes: [.font: UIFont.systemFont(ofSize: 14)]))
        return attributedString
    }
    
    // 데이터를 모두 viewModel에 넣으려고 viewModel에서 사이즈 설정 => UICollectionViewDelegateFlowLayout (CommentController)
    func size(forWidth width: CGFloat) -> CGSize {
        let label = UILabel()
        label.numberOfLines = 0
        label.text = comment.commentText
        label.lineBreakMode = .byWordWrapping
        label.setWidth(width)
        
        return label.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
    }
}
