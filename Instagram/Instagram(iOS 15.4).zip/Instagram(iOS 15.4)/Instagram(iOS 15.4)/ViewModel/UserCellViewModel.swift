//
//  UserCellViewModel.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/04.
//

import UIKit

struct UserCellViewModel {
    let user: User
    
    var profileImageUrl: URL? {
        return URL(string: user.profileImageUrl)
    }
    
    var username: String {
        return user.username
    }
    
    var fullname: String {
        return user.fullname
    }    
    
    init(user: User) {
        self.user = user
    }
}
