//
//  FeedController.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/02.
//

import UIKit
import Firebase

private let reuseIdentifier = "FeedCell"

class FeedController: UICollectionViewController {
    
    // MARK: - Properties
    
    // posts라는 배열에 post를 업로드 하면 추가하는 방식으로 하여 추가된 post의 개수를 얻을수 있고 그 post들을 보이도록한다
    // => SearchController에서 사용한 방식과 유사
    private var posts = [Post]() {
        didSet { collectionView.reloadData() }
    }
    
    // 즉, 기본적으로 우리가하고 싶은 것은이 게시자에게 가치가있는 경우에만,
    //  피드에 게시물 1개를 표시합니다.
    //    그렇지 않은 경우 이 모든 소식을 봅니다.
    //  Profile에서 게시물을 눌렀을때 Feed에 모든 게시물이 아닌 누른 게시물만 나오게 하기 위해
    var post: Post? {
        didSet { self.collectionView.reloadData() }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureViewController()
        fetchPosts()
        
        // => ????
        if post != nil {
            checkIfUserLikedPosts()
        }
    }
    
    // MARK: - Actions
    
    @objc func handleLogOut() {
        do {
            try Auth.auth().signOut()
            // 로그아웃 되면 로그인 페이지가 나와야 한다
            let controller = LoginController()
            
            // => 이해 x
            controller.delegate = self.tabBarController as? MainTabController
            
            let nav = UINavigationController(rootViewController: controller)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav, animated: true, completion: nil)
        } catch {
            print("DEBUG: Failed to log out")
        }
    }
    
    @objc func handleRefresh() {
        posts.removeAll()   // => 모두 지우고
        fetchPosts()        // => 다시 데이터 받기
    }
    
    // MARK: - API
    
    func fetchPosts() {
        guard post == nil else { return }
        
        PostService.fetchFeedPosts { posts in
            self.posts = posts
            self.checkIfUserLikedPosts()
            self.collectionView.refreshControl?.endRefreshing()
        }
    }
    
    //    (posts를 fetch할때마다 좋아요인 상태인지 확인 하지 말고
    //    먼저 모든 posts를 fetch하고 post를 fetch할때 좋아요인 상태인지 확인 ⇒ index활용)
    // 모든 posts를 fetch 하고 모든 posts가 세팅된 후에 실행
    func checkIfUserLikedPosts() {
        if let post = post { // 좋아요인 상태인데 프로필의 포스트를 들어가면 좋아요 UI가 변경이 안되므로
            PostService.checkIfUserLikedPosts(post: post) { didLike in
                self.post?.didLike = didLike
            }
        } else {
            self.posts.forEach { post in
                //    먼저 모든 posts를 fetch하고 post를 fetch할때 좋아요인 상태인지 확인
                PostService.checkIfUserLikedPosts(post: post) { didLike in
                    // print("DEBUG: Post is \(post.caption) and user like is \(post.didLike)")
                    // index를 통해 posts의 didLike를 확인한다
                    if let index = self.posts.firstIndex(where: { $0.postId == post.postId }) {
                        self.posts[index].didLike = didLike
                    }
                }
            }
        }
    }
    
    // MARK: - Helpers
    
    func configureViewController() {
        collectionView.backgroundColor = .white
        
        collectionView.register(FeedCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        if post == nil {
            navigationItem.leftBarButtonItem = UIBarButtonItem(title: "LogOut",
                                                               style: .plain,
                                                               target: self,
                                                               action: #selector(handleLogOut))
        }
        
        navigationItem.title = "Feed"
        
        // 새로고침 UI
        let refresher = UIRefreshControl()
        refresher.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        collectionView.refreshControl = refresher
    }
}

// MARK: - UIColletionViewDataSource

extension FeedController {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //  Profile에서 게시물을 눌렀을때 Feed에 모든 게시물이 아닌 누른 게시물만 나오게 표현
        return post == nil ? posts.count : 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! FeedCell
        cell.delegate = self
        
        if let post = post {    // nil이 아니면 => 해당 포스트만 나오도록
            cell.viewModel = PostViewModel(post: post)
        } else {
            // 알맞은 순서에 맞는 post를 나타내기 위해 index 필요
            cell.viewModel = PostViewModel(post: posts[indexPath.row])
        }
        
        return cell
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension FeedController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = view.frame.width
        var height = width + 8 + 40 + 8
        height += 50
        height += 80
        
        return CGSize(width: width, height: height)
    }
}

// MARK: - FeedCellDelegate

extension FeedController: FeedCellDelegate {
    func cell(_ cell: FeedCell, wantsToShowProfileFor uid: String) {
        UserService.fetchUser(withUid: uid) { user in
            let controller = ProfileController(user: user)
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func cell(_ cell: FeedCell, wantsToShowCommnetsFor post: Post) {
        let controller = CommentController(post: post)
        navigationController?.pushViewController(controller, animated: true)
    }
    
    func cell(_ cell: FeedCell, didLike post: Post) {
        guard let tab = tabBarController as? MainTabController else { return }
        guard let currentUser = tab.user else { return }
        
        // 우리가 원하는 것: didLike가 toggle되면서 좋아요가 되었다가 안되었다가 하는것
        //  => post에 데이터는 viewModel에 있고 우리가 불러오는 데이터는 viewModel에서 불러오는 것이므로 post.didLike.toggle() 이렇게 적으면 x
        //  => MVVM 형식이기 때문 (view가 model을 가지고있지 않고 model은 vieModel이 가지고 있는 패턴)
        cell.viewModel?.post.didLike.toggle()
        
        if post.didLike {
            PostService.unlikePosts(post: post) { _ in
                cell.likeButton.setImage(UIImage(named: "like_unselected"), for: .normal)
                cell.likeButton.tintColor = .black
                cell.viewModel?.post.likes = post.likes - 1
            }
        } else {
            PostService.likePosts(post: post) { _ in
                cell.likeButton.setImage(UIImage(named: "like_selected"), for: .normal)
                cell.likeButton.tintColor = .red
                cell.viewModel?.post.likes = post.likes + 1
                
                // => 게시물 올린 사람의 id, 누가 알림을 보냈는지(현재 로그인 되었을때 알림을 보낸사람), 알림 타입, 특정 게시물
                NotificationService.uploadNotification(toUid: post.ownerUid,
                                                       fromUser: currentUser,
                                                       type: .like, post: post)
            }
        }
    }
}
