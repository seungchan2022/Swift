//
//  MainTabController.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/02.
//

import UIKit
import Firebase
import YPImagePicker

class MainTabController: UITabBarController {
    
    // MARK: - Properties
    
    var user: User? {
        didSet {
            guard let user = user else { return }
            configureViewControllers(withUser: user)
        }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        checkIfUserLoggedIn()
        fetchUser()
    }
    
    // MARK: - API
    
    func fetchUser() {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        UserService.fetchUser(withUid: uid) { user in
            self.user = user
        }
    }
    
    // MARK: - Helpers
    
    // 로그인이 되었으면 바로 메인뷰를 보여주고 로그인이 안된 상태라면 로그인 화면을 보여주기 위해
    func checkIfUserLoggedIn() {
        if Auth.auth().currentUser == nil {
            DispatchQueue.main.async {
                let controller = LoginController()
                
                // 오직 MainTabController가 delegate 프로토콜을 준수하기 때문에 self로 설정 나머지는 x => 올바른 사용자가 로그인 되었는지
                controller.delegate = self
                
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: true, completion: nil)
            }
        }
    }
    
    func configureViewControllers(withUser user: User) {
        view.backgroundColor = .white
        self.delegate = self
        
        // 레이 아웃을 걸면 잘 나타남 ==> ???
        tabBar.backgroundColor = .white.withAlphaComponent(0.8)
        
        //  navigation background 설정
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.8)
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
        
        
        let layout = UICollectionViewFlowLayout()
        let feed = configureTabBarItemImage(unselected: UIImage(named: "home_unselected")!, selected: UIImage (named: "home_selected")!, rootViewController: FeedController(collectionViewLayout: layout))
        
        let search = configureTabBarItemImage(unselected: UIImage(named: "search_unselected")!, selected: UIImage(named: "search_selected")!, rootViewController: SearchController())
        
        let imageSelector = configureTabBarItemImage(unselected: UIImage(named: "plus_unselected")!, selected: UIImage(named: "plus_unselected")!, rootViewController: ImageSelectorController())
        
        let notification = configureTabBarItemImage(unselected: UIImage(named: "like_unselected")!, selected: UIImage(named: "like_selected")!, rootViewController: NotificationController())
        
        let profileController = ProfileController(user: user)
        let profile = configureTabBarItemImage(unselected: UIImage(named: "profile_unselected")!, selected: UIImage(named: "profile_selected")!, rootViewController: profileController)
        
        viewControllers = [feed, search, imageSelector, notification, profile]
        
        tabBar.tintColor = .black
    }
    
    func configureTabBarItemImage(unselected: UIImage, selected: UIImage, rootViewController: UIViewController) -> UINavigationController {
        
        let nav = UINavigationController(rootViewController: rootViewController)
        nav.tabBarItem.image = unselected
        nav.tabBarItem.selectedImage = selected
        nav.navigationBar.tintColor = .black
        
        return nav
    }
    
    // 이미지 선택후 실행할 로직
    func didFinishPickingMedia(_ picker: YPImagePicker) {
        picker.didFinishPicking { items, _ in
            picker.dismiss(animated: false) {
                
                // 선택한 이미지를 가지고 와야된다
                guard let selectedImage = items.singlePhoto?.image else { return }
                
                let controller = UploadPostController()
                controller.selectedImage = selectedImage    // 선택한 이미지가 나오도록
                controller.delegate = self
                
                // 현재 로그인한 유저가 게시물을 업로드
                controller.currentUser = self.user
                let nav = UINavigationController(rootViewController: controller)
                nav.modalPresentationStyle = .fullScreen
                self.present(nav, animated: false, completion: nil)
            }
        }
    }
}

// MARK: - AuthenticationDelegate

extension MainTabController: AuthenticationDelegate {
    func authenticationDidComplete() {
        fetchUser()
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITabBarControllerDelegate

extension MainTabController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        // index가 필요한 이유: MainTab에서 어떤 viewController를 선택했을때 이미지를 선택하는 메서드를 실행해야 되는지 알아야 하기 위해
        let index = viewControllers?.firstIndex(of: viewController)
        
        // tabBarItem에서 ImageSelctor에 해당하는 item을 눌렀을때 UploadPostController가 나타나야한다.
        if index == 2 {
            var config = YPImagePickerConfiguration()
            config.library.mediaType = .photo
            config.shouldSaveNewPicturesToAlbum = false
            config.startOnScreen = .library
            config.screens = [.library]
            config.hidesStatusBar = false
            config.hidesBottomBar = false
            config.library.maxNumberOfItems = 1
            
            let picker = YPImagePicker(configuration: config)
            picker.modalPresentationStyle = .fullScreen
            present(picker, animated: true, completion: nil)
            
            didFinishPickingMedia(picker)
        }
        
        return true
    }
}

// MARK: - UploadPostControllerDelegate

extension MainTabController: UploadPostControllerDelegate {
    
    // 이미지 포스트후 화면이 FeedController를 띄어줘야 된다.
    func controllerDidFinishUploadingPost(_ controller: UploadPostController) {
        selectedIndex = 0
        controller.dismiss(animated: true, completion: nil)
        
        // 이미지 업로드후 업로드한 데이터가 바로 FeedController에 업로드된 상태로 나타나야 한다.
        // => viewControllers를 사용하여 Tabbar의 각 viewController에 접근할 수 있다.
        // => MainTab에 있는 viewController들은 UINavigationController이므로 주의 필요
        // => UINavigationController를 찾고 FeedController를 찾고 FeedController에서 작성했던 handleRefresh 사용 (업데이트를 하여 화면에 게시물이 나오도록)
        // => ??
        guard let feedNav = viewControllers?.first as? UINavigationController else { return }
        guard let feed = feedNav.viewControllers.first as? FeedController else { return }
        feed.handleRefresh()
    }
}
