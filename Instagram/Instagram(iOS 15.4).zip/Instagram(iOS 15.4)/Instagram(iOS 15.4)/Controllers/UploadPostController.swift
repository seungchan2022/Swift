//
//  UploadPostController.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/05.
//

import UIKit

// 업로드후 메인 화면이 나오도록
protocol UploadPostControllerDelegate: class {
    func controllerDidFinishUploadingPost(_ controller: UploadPostController)
}

class UploadPostController: UIViewController {
    
    // MARK: - Properties
    
    // 현재 로그인한 유저가 게시물을 업로드 하므로 currentUser가 필요
    var currentUser: User?
    
    weak var delegate: UploadPostControllerDelegate?
    
    // 선택한 이미지가 나오도록
    var selectedImage: UIImage? {
        didSet { postImageView.image = selectedImage }
    }
    
    private let postImageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()
    
    private lazy var captionTextView: InputTextView = {
        let tv = InputTextView()
        tv.placeholderText = "Enter caption.."
        tv.font = UIFont.systemFont(ofSize: 16)
        tv.delegate = self  // tv의 글자수를 인식하려는 것이므로 여기서 delegate 수행
        tv.placeholderShouldCenter = false
        return tv
    }()
    
    private let characterCountLabel: UILabel = {
        let label = UILabel()
        label.text = "0/100"
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .lightGray
        return label
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }
    
    // MARK: - Actions
    
    @objc func didTapCancel() {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func didTapDone() {
        guard let caption = captionTextView.text else { return }
        guard let image = selectedImage else { return }
        guard let user = currentUser else { return }
        
        showLoader(true)
        
        PostService.uploadPost(caption: caption, image: image, user: user) { error in
            
            self.showLoader(false)  // 오류가 일어나는 말든 무조건 실행하기 위해 여기에 배치
            
            if let error = error {
                print("DEBUG: Failed to upload \(error.localizedDescription)")
                return
            }
            
            print("DEBUG: Sucessfully upload..")
            self.delegate?.controllerDidFinishUploadingPost(self)
        }
    }
    
    // MARK: - Helpers
    
    // 글자수 제한
    func checkMaxLength(_ textView: UITextView) {
        if textView.text.count > 100 {
            textView.deleteBackward()
        }
    }
    
    func configureUI() {
        view.backgroundColor = .white
        navigationItem.title = "Upload Post"
        
        navigationController?.navigationBar.tintColor = .black
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel,
                                                           target: self,
                                                           action: #selector(didTapCancel))
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Share",
                                                            style: .done, target: self,
                                                            action: #selector(didTapDone))
        
        view.addSubview(postImageView)
        postImageView.setDimensions(height: 180, width: 180)
        postImageView.layer.cornerRadius = 10
        postImageView.centerX(inView: view,
                              topAnchor: view.safeAreaLayoutGuide.topAnchor, paddingTop: 8)
                
        view.addSubview(captionTextView)
        captionTextView.anchor(top: postImageView.bottomAnchor,
                               left: view.leftAnchor, right: view.rightAnchor,
                               paddingTop: 16, paddingLeft: 12,
                               paddingRight: 12, height: 64)
                
        view.addSubview(characterCountLabel)
        characterCountLabel.anchor(top: captionTextView.bottomAnchor, right: view.rightAnchor,
                                   paddingTop: 8, paddingRight: 12)
    }
}

// MARK: - UITextViewDelegate

extension UploadPostController: UITextViewDelegate {
    // 해야 할일: 1. captionText의 숫자 계산, 2. 100자 이상 작성 X
    func textViewDidChange(_ textView: UITextView) {
        checkMaxLength(textView)
        
        let count = textView.text.count
        characterCountLabel.text = "\(count)/100"
    }
}
