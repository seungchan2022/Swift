//
//  User.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/04.
//

// 표현할 데이터들을 미리 만들어서 관리 => 이렇게 하면 다른 곳에서도 User에 대한 정보를 사용할때 마다 만들지 않고 사용할 수 있다
// UserService의 fetchUser를 통해 사용자 데이터를 얻고 모델링하는데 도움이 되는 사용자 지정 개체 만들기 (기본적으로 모두가 캡슐화할 수 있기를 원하므로)

import Firebase

struct User {
    let email: String
    let fullname: String
    let profileImageUrl: String
    let uid: String
    let username: String
    
    // follow인지 unfollow인지 확인할 변수
    var isFollowed = false
    
    // 불러온 사용자가 현재 로그인된 사용자인지 확인 (현재 로그인된 사용자가 불러온 사용자이면 follow 나 following표시 x)
    var isCurrentUser: Bool { return Auth.auth().currentUser?.uid == uid }
    
    var stats: UserStats!
    
    // 초기값 설정 (여기서 초기값을 설정하지 않으면 다른 곳에서 데이터를 부르려고 할때 마다 작성해주어야 한다)
    init(dictionary: [String: Any]) {
        self.email = dictionary["email"] as? String ?? ""
        self.fullname = dictionary["fullname"] as? String ?? ""
        self.profileImageUrl = dictionary["profileImageUrl"] as? String ?? ""
        self.uid = dictionary["uid"] as? String ?? ""
        self.username = dictionary["username"] as? String ?? ""
        
        self.stats = UserStats(followers: 0, following: 0, posts: 0)
    }
}

struct UserStats {
    let followers: Int
    let following: Int
    let posts: Int
}
