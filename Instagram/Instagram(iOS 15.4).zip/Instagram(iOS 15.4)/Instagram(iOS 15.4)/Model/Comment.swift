//
//  Comment.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/09.
//

import Firebase

struct Comment {
    let commentText: String
    let profileImageUrl: String
    let timestamp: Timestamp
    let uid: String
    let username: String
    
    init(dictionary: [String: Any]) {
        self.commentText = dictionary["comment"] as? String ?? ""
        self.profileImageUrl = dictionary["profileImageUrl"] as? String ?? ""
        self.timestamp = dictionary["timestamp"] as? Timestamp ?? Timestamp(date: Date())
        self.uid = dictionary["uid"] as? String ?? ""
        self.username = dictionary["username"] as? String ?? ""
    }
}
