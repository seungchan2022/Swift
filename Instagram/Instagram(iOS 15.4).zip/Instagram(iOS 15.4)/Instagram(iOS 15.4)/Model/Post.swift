//
//  Post.swift
//  Instagram(iOS 15.4)
//
//  Created by 승찬 on 2023/05/06.
//

import UIKit
import Firebase

struct Post {
    var caption: String
    var likes: Int
    let imageUrl: String    // postImage
    let ownerUid: String
    let timestamp: Timestamp
    let postId: String
    let ownerUsername: String
    let ownerImageUrl: String
    
    // 좋아요 눌렀는지 아닌지 => User의 isFollowed와 같음
    var didLike = false
    
    init(postId: String, dictionary: [String: Any]) {
        self.postId = postId    // firestore에 postId의 데이터를 넣지 않기 때문에 이렇게 표현
        self.caption = dictionary["caption"] as? String ?? ""
        self.likes = dictionary["likes"] as? Int ?? 0
        self.imageUrl = dictionary["imageUrl"] as? String ?? ""
        self.ownerUid = dictionary["ownerUid"] as? String ?? ""
        self.timestamp = dictionary["timestamp"] as? Timestamp ?? Timestamp(date: Date())
        self.ownerUsername = dictionary["ownerUsername"] as? String ?? ""
        self.ownerImageUrl = dictionary["ownerImageUrl"] as? String ?? ""
    }
}
